#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <FS.h>
#include <LittleFS.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEService.h>
#include <BLECharacteristic.h>
#include <BLEDescriptor.h>
#include <BLE2902.h>
#include <esp_arduino_version.h>
#include <sys/time.h>
#include <vector>
#include <algorithm>

#define AP_SSID "RyzMusical-ESP32"
#define AP_PASS "ryz12345"
#define STA_SSID ""
#define STA_PASS ""
#define BUZZER_PIN 25
#define LEDC_RES 10
#define MUSIC_DIR "/music"

#define NUS_SERVICE_UUID "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
#define NUS_TX_UUID "6e400003-b5a3-f393-e0a9-e50e24dcca9e"
#define NUS_RX_UUID "6e400002-b5a3-f393-e0a9-e50e24dcca9e"
#define FFE0_SERVICE_UUID "0000ffe0-0000-1000-8000-00805f9b34fb"
#define FFE1_CHAR_UUID "0000ffe1-0000-1000-8000-00805f9b34fb"

struct MidiEvent {
  uint32_t us;
  uint32_t tick;
  uint32_t tempo;
  uint8_t type;
  uint8_t note;
  uint8_t vel;
};

struct PlayerState {
  std::vector<MidiEvent> events;
  std::vector<String> fileList;
  String currentName;
  int fileIdx;
  bool playing;
  bool paused;
  bool loaded;
  size_t cursor;
  uint64_t durationUs;
  uint64_t startUs;
  uint64_t wallStart;
  float mult;
  int volumePercent;
  uint32_t usPerQuarter;
  uint32_t tpq;
  SemaphoreHandle_t lock;
};

static PlayerState player;
static WebServer server(80);
static BLECharacteristic* nusTxChar = nullptr;
static BLECharacteristic* ffe1Char = nullptr;
static String bleLineBuf = "";
static int activeNotes[128];

static inline uint16_t rd16(const uint8_t* p){ return ((uint16_t)p[0] << 8) | p[1]; }
static inline uint32_t rd32(const uint8_t* p){ return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3]; }

static size_t readVlq(const uint8_t* data, size_t len, size_t pos, uint32_t* out){
  uint32_t value = 0;
  uint8_t count = 0;
  while(pos < len && count < 4){
    uint8_t b = data[pos++];
    value = (value << 7) | (b & 0x7F);
    count++;
    if(!(b & 0x80)){ *out = value; return pos; }
  }
  return 0;
}

static int b64Val(char c){
  if(c >= 'A' && c <= 'Z') return c - 'A';
  if(c >= 'a' && c <= 'z') return c - 'a' + 26;
  if(c >= '0' && c <= '9') return c - '0' + 52;
  if(c == '+') return 62;
  if(c == '/') return 63;
  return -1;
}

static size_t base64Decode(const String& in, uint8_t* out, size_t outMax){
  size_t o = 0;
  uint32_t acc = 0;
  int bits = 0;
  for(size_t i = 0; i < in.length() && o < outMax; i++){
    int v = b64Val(in[i]);
    if(v < 0) continue;
    acc = (acc << 6) | (uint32_t)v;
    bits += 6;
    if(bits >= 8){
      bits -= 8;
      out[o++] = (uint8_t)((acc >> bits) & 0xFF);
    }
  }
  return o;
}

static bool parseMidiBuffer(const uint8_t* data, size_t len, std::vector<MidiEvent>& out, uint32_t& usPerQuarterOut, uint32_t& tpqOut){
  out.clear();
  if(len < 14 || rd32(data) != 0x4D546864) return false;
  uint32_t headerLen = rd32(data + 4);
  if(headerLen < 6) return false;
  uint16_t ntrks = rd16(data + 10);
  uint16_t division = rd16(data + 12);
  uint32_t ticksPerSecond = 0;
  if(division & 0x8000){
    int8_t fps = (int8_t)(division >> 8);
    uint8_t tpf = division & 0xFF;
    if(fps >= 0 || tpf == 0) return false;
    fps = -fps;
    ticksPerSecond = (uint32_t)fps * tpf;
  }
  uint32_t tpq = (division & 0x8000) ? 480 : (division == 0 ? 480 : division);
  uint32_t firstTempo = 500000;
  bool tempoFound = false;
  size_t pos = 8 + headerLen;
  std::vector<MidiEvent> raw;
  uint16_t tracksSeen = 0;
  while(pos + 8 <= len && tracksSeen < ntrks){
    uint32_t chunkId = rd32(data + pos);
    uint32_t chunkLen = rd32(data + pos + 4);
    size_t chunkStart = pos + 8;
    if(chunkId != 0x4D54726B){
      pos = chunkStart + chunkLen;
      continue;
    }
    tracksSeen++;
    size_t chunkEnd = chunkStart + chunkLen;
    if(chunkEnd > len) chunkEnd = len;
    size_t p = chunkStart;
    uint32_t tick = 0;
    uint8_t runningStatus = 0;
    while(p < chunkEnd){
      uint32_t delta = 0;
      size_t np = readVlq(data, chunkEnd, p, &delta);
      if(np == 0) break;
      p = np;
      tick += delta;
      if(p >= chunkEnd) break;
      uint8_t status = data[p];
      if(status & 0x80){
        p++;
        if(status < 0xF0) runningStatus = status;
        else runningStatus = 0;
      }else{
        status = runningStatus;
        if(!(status & 0x80)) break;
      }
      uint8_t typeNib = status & 0xF0;
      if(status == 0xFF){
        if(p >= chunkEnd) break;
        uint8_t metaType = data[p++];
        uint32_t metaLen = 0;
        np = readVlq(data, chunkEnd, p, &metaLen);
        if(np == 0) break;
        p = np;
        if(metaType == 0x51 && metaLen == 3 && p + 3 <= chunkEnd){
          uint32_t tempo = ((uint32_t)data[p] << 16) | ((uint32_t)data[p + 1] << 8) | data[p + 2];
          if(tempo > 0){
            if(!tempoFound){
              firstTempo = tempo;
              tempoFound = true;
            }
            MidiEvent ev;
            ev.us = 0;
            ev.tick = tick;
            ev.tempo = tempo;
            ev.type = 2;
            ev.note = 0;
            ev.vel = 0;
            raw.push_back(ev);
          }
        }
        p += metaLen;
        if(metaType == 0x2F) break;
      }else if(status == 0xF0 || status == 0xF7){
        uint32_t sysexLen = 0;
        np = readVlq(data, chunkEnd, p, &sysexLen);
        if(np == 0) break;
        p = np + sysexLen;
      }else if(typeNib == 0x80 || typeNib == 0x90 || typeNib == 0xA0 || typeNib == 0xB0 || typeNib == 0xE0){
        if(p + 2 > chunkEnd) break;
        uint8_t d1 = data[p];
        uint8_t d2 = data[p + 1];
        p += 2;
        if(typeNib == 0x90 && d2 > 0){
          MidiEvent ev;
          ev.us = 0;
          ev.tick = tick;
          ev.tempo = 0;
          ev.type = 1;
          ev.note = d1 & 0x7F;
          ev.vel = d2;
          raw.push_back(ev);
        }else if(typeNib == 0x80 || typeNib == 0x90){
          MidiEvent ev;
          ev.us = 0;
          ev.tick = tick;
          ev.tempo = 0;
          ev.type = 0;
          ev.note = d1 & 0x7F;
          ev.vel = 0;
          raw.push_back(ev);
        }
      }else if(typeNib == 0xC0 || typeNib == 0xD0){
        if(p + 1 > chunkEnd) break;
        p += 1;
      }
    }
    pos = chunkStart + chunkLen;
  }
  if(raw.size() == 0) return false;
  std::stable_sort(raw.begin(), raw.end(), [](const MidiEvent& a, const MidiEvent& b){
    if(a.tick != b.tick) return a.tick < b.tick;
    int pa = a.type == 0 ? 0 : (a.type == 2 ? 1 : 2);
    int pb = b.type == 0 ? 0 : (b.type == 2 ? 1 : 2);
    return pa < pb;
  });
  uint64_t absUs = 0;
  uint32_t prevTick = 0;
  uint32_t curUsPerQuarter = 500000;
  for(size_t i = 0; i < raw.size(); i++){
    MidiEvent ev = raw[i];
    if(ticksPerSecond > 0){
      if(ev.type == 2) continue;
      ev.us = (uint32_t)((uint64_t)ev.tick * 1000000ULL / ticksPerSecond);
    }else{
      absUs += (uint64_t)(ev.tick - prevTick) * curUsPerQuarter / tpq;
      prevTick = ev.tick;
      ev.us = (uint32_t)absUs;
      if(ev.type == 2) curUsPerQuarter = ev.tempo;
    }
    out.push_back(ev);
  }
  usPerQuarterOut = ticksPerSecond > 0 ? 500000 : firstTempo;
  tpqOut = tpq;
  return true;
}

static void buzzerTone(float freq){
  if(BUZZER_PIN < 0) return;
  int duty = (int)(512.0f * player.volumePercent / 100.0f);
  if(duty < 1) duty = 1;
#if ESP_ARDUINO_VERSION >= ESP_ARDUINO_VERSION_VAL(3,0,0)
  if(freq <= 0){ ledcWriteTone(BUZZER_PIN, 0); return; }
  ledcWriteTone(BUZZER_PIN, freq);
  ledcWrite(BUZZER_PIN, duty);
#else
  if(freq <= 0){ ledcWriteTone(0, 0); return; }
  ledcWriteTone(0, freq);
  ledcWrite(0, duty);
#endif
}

static void buzzerSetup(){
  if(BUZZER_PIN < 0) return;
#if ESP_ARDUINO_VERSION >= ESP_ARDUINO_VERSION_VAL(3,0,0)
  ledcAttach(BUZZER_PIN, 2000, LEDC_RES);
#else
  ledcSetup(0, 2000, LEDC_RES);
  ledcAttachPin(BUZZER_PIN, 0);
#endif
  buzzerTone(0);
}

static void clearActiveNotes(){
  for(int i = 0; i < 128; i++) activeNotes[i] = -1;
  buzzerTone(0);
}

static void refreshBuzzer(){
  int best = -1;
  for(int i = 0; i < 128; i++){
    if(activeNotes[i] >= 0) best = i;
  }
  if(best < 0){ buzzerTone(0); return; }
  float freq = 440.0f * powf(2.0f, (best - 69) / 12.0f);
  buzzerTone(freq);
}

static void stopPlaybackLocked(){
  player.playing = false;
  player.paused = false;
  player.cursor = 0;
  player.startUs = 0;
}

static bool loadSongByIndexLocked(int index){
  if(index < 0 || index >= (int)player.fileList.size()) return false;
  String name = player.fileList[index];
  String path = String(MUSIC_DIR) + "/" + name;
  File f = LittleFS.open(path, "r");
  if(!f) return false;
  size_t size = f.size();
  if(size < 14){ f.close(); return false; }
  uint8_t* buf = (uint8_t*)malloc(size);
  if(!buf){ f.close(); return false; }
  size_t got = f.read(buf, size);
  f.close();
  std::vector<MidiEvent> events;
  uint32_t usPerQuarter = 500000;
  uint32_t tpq = 480;
  bool ok = parseMidiBuffer(buf, got, events, usPerQuarter, tpq);
  free(buf);
  if(!ok) return false;
  player.events = events;
  player.currentName = name;
  player.fileIdx = index;
  player.loaded = true;
  player.playing = false;
  player.paused = false;
  player.cursor = 0;
  player.startUs = 0;
  player.tpq = tpq;
  player.usPerQuarter = usPerQuarter;
  uint64_t maxUs = 0;
  for(size_t i = 0; i < events.size(); i++){
    if(events[i].type != 2 && events[i].us > maxUs) maxUs = events[i].us;
  }
  player.durationUs = maxUs;
  clearActiveNotes();
  return true;
}

static void refreshFileListLocked(){
  player.fileList.clear();
  File dir = LittleFS.open(MUSIC_DIR);
  if(!dir) return;
  File entry = dir.openNextFile();
  while(entry){
    if(!entry.isDirectory()){
      String n = String(entry.name());
      int slash = n.lastIndexOf('/');
      if(slash >= 0) n = n.substring(slash + 1);
      if(n.length() > 0) player.fileList.push_back(n);
    }
    entry.close();
    entry = dir.openNextFile();
  }
  dir.close();
  std::sort(player.fileList.begin(), player.fileList.end(), [](const String& a, const String& b){
    return a.compareTo(b) < 0;
  });
}

static uint64_t songPositionUsLocked(){
  if(!player.playing && !player.paused) return player.startUs;
  uint64_t elapsed = (uint64_t)((micros() - player.wallStart) * player.mult);
  uint64_t pos = player.startUs + elapsed;
  if(pos > player.durationUs) pos = player.durationUs;
  return pos;
}

static void statusJsonLocked(String& out){
  uint64_t pos = songPositionUsLocked();
  uint64_t remain = pos < player.durationUs ? (player.durationUs - pos) : 0;
  float rawBpm = player.usPerQuarter > 0 ? (60000000.0f / player.usPerQuarter) : 120.0f;
  float effBpm = rawBpm * player.mult;
  out += "{\"playing\":";
  out += (player.playing && !player.paused) ? "true" : "false";
  out += ",\"paused\":";
  out += player.paused ? "true" : "false";
  out += ",\"fileIdx\":";
  out += String(player.fileIdx);
  out += ",\"durationSec\":";
  out += String(player.durationUs / 1000000ULL, 3);
  out += ",\"sisaSec\":";
  out += String(remain / 1000000ULL, 3);
  out += ",\"mult\":";
  out += String(player.mult, 2);
  out += ",\"effBpm\":";
  out += String((int)effBpm);
  out += ",\"midiRawBpm\":";
  out += String((int)rawBpm);
  out += ",\"volumePercent\":";
  out += String(player.volumePercent);
  out += ",\"fileCount\":";
  out += String(player.fileList.size());
  out += ",\"name\":\"";
  out += player.currentName;
  out += "\"}";
}

static void sendCors(){
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
}

static void respondJson(int code, const String& body){
  sendCors();
  server.send(code, "application/json", body);
}

static void handleStatus(){
  String out;
  xSemaphoreTake(player.lock, portMAX_DELAY);
  statusJsonLocked(out);
  xSemaphoreGive(player.lock);
  respondJson(200, out);
}

static void handleFiles(){
  String out = "[";
  xSemaphoreTake(player.lock, portMAX_DELAY);
  for(size_t i = 0; i < player.fileList.size(); i++){
    if(i > 0) out += ",";
    out += "{\"name\":\"" + player.fileList[i] + "\"}";
  }
  xSemaphoreGive(player.lock);
  out += "]";
  respondJson(200, out);
}

static void handleActiveNotes(){
  String out = "[";
  bool first = true;
  xSemaphoreTake(player.lock, portMAX_DELAY);
  for(int i = 0; i < 128; i++){
    if(activeNotes[i] < 0) continue;
    if(!first) out += ",";
    first = false;
    out += "{\"note\":" + String(i) + ",\"vel\":" + String(activeNotes[i]) + ",\"rel\":0}";
  }
  xSemaphoreGive(player.lock);
  out += "]";
  respondJson(200, out);
}

static void handleSelect(){
  int index = server.hasArg("idx") ? server.arg("idx").toInt() : -1;
  bool ok = false;
  xSemaphoreTake(player.lock, portMAX_DELAY);
  ok = loadSongByIndexLocked(index);
  if(ok){
    player.playing = true;
    player.paused = false;
    player.wallStart = micros();
  }
  xSemaphoreGive(player.lock);
  respondJson(200, ok ? "{\"ok\":true}" : "{\"err\":\"no file\"}");
}

static void handlePlay(){
  xSemaphoreTake(player.lock, portMAX_DELAY);
  if(player.loaded && !player.playing){
    player.playing = true;
    player.paused = false;
    player.wallStart = micros();
  }
  xSemaphoreGive(player.lock);
  respondJson(200, "{\"ok\":true}");
}

static void handlePause(){
  xSemaphoreTake(player.lock, portMAX_DELAY);
  if(player.playing && !player.paused){
    player.startUs = songPositionUsLocked();
    player.playing = false;
    player.paused = true;
    clearActiveNotes();
  }
  xSemaphoreGive(player.lock);
  respondJson(200, "{\"ok\":true}");
}

static void handleResume(){
  xSemaphoreTake(player.lock, portMAX_DELAY);
  if(player.paused){
    player.paused = false;
    player.playing = true;
    player.wallStart = micros();
  }
  xSemaphoreGive(player.lock);
  respondJson(200, "{\"ok\":true}");
}

static void handleStop(){
  xSemaphoreTake(player.lock, portMAX_DELAY);
  stopPlaybackLocked();
  clearActiveNotes();
  xSemaphoreGive(player.lock);
  respondJson(200, "{\"ok\":true}");
}

static void handleSeek(){
  uint32_t sec = server.hasArg("sec") ? server.arg("sec").toInt() : 0;
  xSemaphoreTake(player.lock, portMAX_DELAY);
  uint64_t target = (uint64_t)sec * 1000000ULL;
  if(target > player.durationUs) target = player.durationUs;
  player.startUs = target;
  player.wallStart = micros();
  clearActiveNotes();
  size_t i = 0;
  while(i < player.events.size() && player.events[i].us <= target) i++;
  player.cursor = i;
  xSemaphoreGive(player.lock);
  respondJson(200, "{\"ok\":true}");
}

static void handleVolume(){
  int v = server.hasArg("v") ? server.arg("v").toInt() : 50;
  if(v < 0) v = 0;
  if(v > 100) v = 100;
  xSemaphoreTake(player.lock, portMAX_DELAY);
  player.volumePercent = v;
  xSemaphoreGive(player.lock);
  refreshBuzzer();
  respondJson(200, "{\"ok\":true,\"volumePercent\":" + String(v) + "}");
}

static void handleMult(){
  float m = server.hasArg("v") ? server.arg("v").toFloat() : 1.0f;
  if(m < 0.5f) m = 0.5f;
  if(m > 2.0f) m = 2.0f;
  xSemaphoreTake(player.lock, portMAX_DELAY);
  if(player.playing){
    player.startUs = songPositionUsLocked();
    player.wallStart = micros();
  }
  player.mult = m;
  xSemaphoreGive(player.lock);
  respondJson(200, "{\"ok\":true,\"mult\":" + String(m, 2) + "}");
}

static void handleTestNote(){
  int note = server.hasArg("note") ? server.arg("note").toInt() : 60;
  int on = server.hasArg("on") ? server.arg("on").toInt() : 1;
  if(note < 0 || note > 127){
    respondJson(200, "{\"err\":\"note range\"}");
    return;
  }
  xSemaphoreTake(player.lock, portMAX_DELAY);
  activeNotes[note] = on ? 100 : -1;
  xSemaphoreGive(player.lock);
  refreshBuzzer();
  respondJson(200, "{\"ok\":true}");
}

static void handleSetClock(){
  struct timeval tv;
  struct tm t;
  memset(&t, 0, sizeof(t));
  t.tm_year = (server.hasArg("year") ? server.arg("year").toInt() : 2026) - 1900;
  t.tm_mon = (server.hasArg("month") ? server.arg("month").toInt() : 1) - 1;
  t.tm_mday = server.hasArg("day") ? server.arg("day").toInt() : 1;
  t.tm_hour = server.hasArg("hour") ? server.arg("hour").toInt() : 0;
  t.tm_min = server.hasArg("minute") ? server.arg("minute").toInt() : 0;
  t.tm_sec = server.hasArg("second") ? server.arg("second").toInt() : 0;
  tv.tv_sec = mktime(&t);
  tv.tv_usec = 0;
  settimeofday(&tv, nullptr);
  respondJson(200, "{\"ok\":true}");
}

static void purgeCurrentLocked(const String& name){
  stopPlaybackLocked();
  clearActiveNotes();
  if(player.currentName == name){
    player.currentName = "";
    player.fileIdx = -1;
    player.loaded = false;
    player.events.clear();
    player.durationUs = 0;
  }
}

static void handleDelete(){
  String name = server.hasArg("name") ? server.arg("name") : "";
  bool ok = false;
  if(name.length() > 0 && name.indexOf("..") < 0 && name.indexOf('/') < 0){
    xSemaphoreTake(player.lock, portMAX_DELAY);
    ok = LittleFS.remove(String(MUSIC_DIR) + "/" + name);
    refreshFileListLocked();
    purgeCurrentLocked(name);
    xSemaphoreGive(player.lock);
  }
  respondJson(200, ok ? "{\"ok\":true}" : "{\"err\":\"not found\"}");
}

static void handleRename(){
  String name = server.hasArg("name") ? server.arg("name") : "";
  String newName = server.hasArg("newname") ? server.arg("newname") : "";
  bool ok = false;
  if(name.length() > 0 && newName.length() > 0 && name.indexOf("..") < 0 && newName.indexOf("..") < 0 && name.indexOf('/') < 0 && newName.indexOf('/') < 0){
    xSemaphoreTake(player.lock, portMAX_DELAY);
    ok = LittleFS.rename(String(MUSIC_DIR) + "/" + name, String(MUSIC_DIR) + "/" + newName);
    refreshFileListLocked();
    if(ok && player.currentName == name) player.currentName = newName;
    xSemaphoreGive(player.lock);
  }
  respondJson(200, ok ? "{\"ok\":true}" : "{\"err\":\"rename failed\"}");
}

static void handleUpload(){
  String name = server.hasArg("name") ? server.arg("name") : "";
  String body = server.arg("plain");
  bool ok = false;
  if(name.length() > 0 && body.length() > 8 && name.indexOf("..") < 0 && name.indexOf('/') < 0){
    size_t maxOut = (body.length() / 4) * 3 + 4;
    uint8_t* buf = (uint8_t*)malloc(maxOut);
    if(buf){
      size_t decoded = base64Decode(body, buf, maxOut);
      if(decoded >= 14){
        File f = LittleFS.open(String(MUSIC_DIR) + "/" + name, "w");
        if(f){
          size_t written = f.write(buf, decoded);
          f.close();
          ok = written == decoded;
        }
        if(ok){
          xSemaphoreTake(player.lock, portMAX_DELAY);
          refreshFileListLocked();
          xSemaphoreGive(player.lock);
        }
      }
      free(buf);
    }
  }
  respondJson(200, ok ? "{\"ok\":true}" : "{\"err\":\"upload failed\"}");
}

static void handleUploadNotify(){
  respondJson(200, "{\"ok\":true}");
}

static void handleOptions(){
  sendCors();
  server.send(204, "text/plain", "");
}

static void bleNotify(const String& payload){
  String data = payload + "\n";
  size_t pos = 0;
  while(pos < data.length()){
    size_t chunkLen = data.length() - pos;
    if(chunkLen > 380) chunkLen = 380;
    String chunk = data.substring(pos, pos + chunkLen);
    if(nusTxChar){
      nusTxChar->setValue((uint8_t*)chunk.c_str(), chunk.length());
      nusTxChar->notify();
    }
    if(ffe1Char){
      ffe1Char->setValue((uint8_t*)chunk.c_str(), chunk.length());
      ffe1Char->notify();
    }
    pos += chunkLen;
    if(pos < data.length()) delay(6);
  }
}

static void handleCommand(String line){
  line.trim();
  if(line.length() == 0) return;
  int sp = line.indexOf(' ');
  String verb = sp < 0 ? line : line.substring(0, sp);
  String rest = sp < 0 ? "" : line.substring(sp + 1);
  verb.toUpperCase();
  String response = "{\"err\":\"unknown\"}";
  if(verb == "STATUS"){
    xSemaphoreTake(player.lock, portMAX_DELAY);
    statusJsonLocked(response);
    xSemaphoreGive(player.lock);
  }else if(verb == "FILES"){
    String out = "[";
    xSemaphoreTake(player.lock, portMAX_DELAY);
    for(size_t i = 0; i < player.fileList.size(); i++){
      if(i > 0) out += ",";
      out += "{\"name\":\"" + player.fileList[i] + "\"}";
    }
    xSemaphoreGive(player.lock);
    out += "]";
    response = out;
  }else if(verb == "NOTES"){
    String out = "[";
    bool first = true;
    xSemaphoreTake(player.lock, portMAX_DELAY);
    for(int i = 0; i < 128; i++){
      if(activeNotes[i] < 0) continue;
      if(!first) out += ",";
      first = false;
      out += "{\"note\":" + String(i) + ",\"vel\":" + String(activeNotes[i]) + ",\"rel\":0}";
    }
    xSemaphoreGive(player.lock);
    out += "]";
    response = out;
  }else if(verb == "PLAY" || verb == "PAUSE" || verb == "RESUME" || verb == "STOP"){
    xSemaphoreTake(player.lock, portMAX_DELAY);
    if(verb == "PLAY" && player.loaded && !player.playing && !player.paused){
      player.playing = true;
      player.wallStart = micros();
    }else if(verb == "PAUSE" && player.playing && !player.paused){
      player.startUs = songPositionUsLocked();
      player.playing = false;
      player.paused = true;
      clearActiveNotes();
    }else if(verb == "RESUME" && player.paused){
      player.paused = false;
      player.playing = true;
      player.wallStart = micros();
    }else if(verb == "STOP"){
      stopPlaybackLocked();
      clearActiveNotes();
    }
    response = "{\"ok\":true}";
    xSemaphoreGive(player.lock);
  }else if(verb == "SELECT"){
    int index = rest.toInt();
    xSemaphoreTake(player.lock, portMAX_DELAY);
    bool ok = loadSongByIndexLocked(index);
    if(ok){
      player.playing = true;
      player.paused = false;
      player.wallStart = micros();
    }
    xSemaphoreGive(player.lock);
    response = ok ? "{\"ok\":true}" : "{\"err\":\"no file\"}";
  }else if(verb == "SEEK"){
    uint64_t target = (uint64_t)(rest.toInt()) * 1000000ULL;
    xSemaphoreTake(player.lock, portMAX_DELAY);
    if(target > player.durationUs) target = player.durationUs;
    player.startUs = target;
    player.wallStart = micros();
    clearActiveNotes();
    size_t i = 0;
    while(i < player.events.size() && player.events[i].us <= target) i++;
    player.cursor = i;
    xSemaphoreGive(player.lock);
    response = "{\"ok\":true}";
  }else if(verb == "VOL"){
    int v = rest.toInt();
    if(v < 0) v = 0;
    if(v > 100) v = 100;
    xSemaphoreTake(player.lock, portMAX_DELAY);
    player.volumePercent = v;
    xSemaphoreGive(player.lock);
    refreshBuzzer();
    response = "{\"ok\":true,\"volumePercent\":" + String(v) + "}";
  }else if(verb == "MULT"){
    float m = rest.toFloat();
    if(m < 0.5f) m = 0.5f;
    if(m > 2.0f) m = 2.0f;
    xSemaphoreTake(player.lock, portMAX_DELAY);
    if(player.playing){
      player.startUs = songPositionUsLocked();
      player.wallStart = micros();
    }
    player.mult = m;
    xSemaphoreGive(player.lock);
    response = "{\"ok\":true,\"mult\":" + String(m, 2) + "}";
  }else if(verb == "NOTE"){
    int sp2 = rest.indexOf(' ');
    int note = (sp2 < 0 ? rest : rest.substring(0, sp2)).toInt();
    String state = sp2 < 0 ? "ON" : rest.substring(sp2 + 1);
    state.toUpperCase();
    state.trim();
    if(note >= 0 && note <= 127){
      xSemaphoreTake(player.lock, portMAX_DELAY);
      activeNotes[note] = state == "OFF" ? -1 : 100;
      xSemaphoreGive(player.lock);
      refreshBuzzer();
      response = "{\"ok\":true}";
    }else{
      response = "{\"err\":\"note range\"}";
    }
  }else if(verb == "DEL"){
    if(rest.length() > 0 && rest.indexOf("..") < 0 && rest.indexOf('/') < 0){
      xSemaphoreTake(player.lock, portMAX_DELAY);
      bool ok = LittleFS.remove(String(MUSIC_DIR) + "/" + rest);
      refreshFileListLocked();
      purgeCurrentLocked(rest);
      xSemaphoreGive(player.lock);
      response = ok ? "{\"ok\":true}" : "{\"err\":\"not found\"}";
    }else{
      response = "{\"err\":\"bad name\"}";
    }
  }else if(verb == "RENAME"){
    int bar = rest.indexOf('|');
    if(bar > 0){
      String oldName = rest.substring(0, bar);
      String newName = rest.substring(bar + 1);
      oldName.trim();
      newName.trim();
      if(oldName.length() > 0 && newName.length() > 0 && oldName.indexOf("..") < 0 && newName.indexOf("..") < 0 && oldName.indexOf('/') < 0 && newName.indexOf('/') < 0){
        xSemaphoreTake(player.lock, portMAX_DELAY);
        bool ok = LittleFS.rename(String(MUSIC_DIR) + "/" + oldName, String(MUSIC_DIR) + "/" + newName);
        refreshFileListLocked();
        if(ok && player.currentName == oldName) player.currentName = newName;
        xSemaphoreGive(player.lock);
        response = ok ? "{\"ok\":true}" : "{\"err\":\"rename failed\"}";
      }else{
        response = "{\"err\":\"bad name\"}";
      }
    }
  }
  bleNotify(response);
}

class RxCallback : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic* characteristic) override {
    String value = characteristic->getValue();
    for(size_t i = 0; i < value.length(); i++){
      char c = value[i];
      if(c == '\n' || c == '\r'){
        if(bleLineBuf.length() > 0){
          handleCommand(bleLineBuf);
          bleLineBuf = "";
        }
      }else{
        bleLineBuf += c;
        if(bleLineBuf.length() > 512) bleLineBuf = "";
      }
    }
  }
};

static void registerEndpoint(const char* uri, void (*handler)()){
  server.on(uri, HTTP_GET, handler);
  server.on(uri, HTTP_POST, handler);
}

void setup(){
  Serial.begin(115200);
  player.playing = false;
  player.paused = false;
  player.loaded = false;
  player.fileIdx = -1;
  player.cursor = 0;
  player.durationUs = 0;
  player.startUs = 0;
  player.wallStart = 0;
  player.mult = 1.0f;
  player.volumePercent = 70;
  player.usPerQuarter = 500000;
  player.tpq = 480;
  player.lock = xSemaphoreCreateMutex();
  for(int i = 0; i < 128; i++) activeNotes[i] = -1;
  buzzerSetup();
  if(!LittleFS.begin(true)){
    Serial.println("LittleFS gagal dimuat");
  }
  LittleFS.mkdir(MUSIC_DIR);
  xSemaphoreTake(player.lock, portMAX_DELAY);
  refreshFileListLocked();
  xSemaphoreGive(player.lock);
  WiFi.mode(WIFI_AP_STA);
  bool staTried = false;
  if(strlen(STA_SSID) > 0){
    staTried = true;
    WiFi.begin(STA_SSID, STA_PASS);
    uint32_t waitStart = millis();
    while(WiFi.status() != WL_CONNECTED && millis() - waitStart < 8000){ delay(200); }
  }
  WiFi.softAP(AP_SSID, AP_PASS);
  Serial.print("AP IP: ");
  Serial.println(WiFi.softAPIP());
  if(staTried && WiFi.status() == WL_CONNECTED){
    Serial.print("STA IP: ");
    Serial.println(WiFi.localIP());
  }
  registerEndpoint("/api/status", handleStatus);
  registerEndpoint("/api/files", handleFiles);
  registerEndpoint("/api/activenotes", handleActiveNotes);
  registerEndpoint("/api/select", handleSelect);
  registerEndpoint("/api/play", handlePlay);
  registerEndpoint("/api/pause", handlePause);
  registerEndpoint("/api/resume", handleResume);
  registerEndpoint("/api/stop", handleStop);
  registerEndpoint("/api/seek", handleSeek);
  registerEndpoint("/api/volume", handleVolume);
  registerEndpoint("/api/mult", handleMult);
  registerEndpoint("/api/testnote", handleTestNote);
  registerEndpoint("/api/setclock", handleSetClock);
  registerEndpoint("/api/delete", handleDelete);
  registerEndpoint("/api/renamefile", handleRename);
  registerEndpoint("/api/upload", handleUpload);
  registerEndpoint("/api/uploadnotify", handleUploadNotify);
  server.onNotFound(handleOptions);
  server.begin();
  BLEDevice::init("RyzMusical-ESP32");
  BLEServer* bleServer = BLEDevice::createServer();
  BLEService* nusService = bleServer->createService(NUS_SERVICE_UUID);
  nusTxChar = nusService->createCharacteristic(NUS_TX_UUID, BLECharacteristic::PROPERTY_NOTIFY);
  nusTxChar->addDescriptor(new BLE2902());
  BLECharacteristic* nusRxChar = nusService->createCharacteristic(NUS_RX_UUID, BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR);
  nusRxChar->setCallbacks(new RxCallback());
  nusService->start();
  BLEService* ffeService = bleServer->createService(FFE0_SERVICE_UUID);
  ffe1Char = ffeService->createCharacteristic(FFE1_CHAR_UUID, BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_WRITE_NR | BLECharacteristic::PROPERTY_NOTIFY);
  ffe1Char->addDescriptor(new BLE2902());
  ffe1Char->setCallbacks(new RxCallback());
  ffeService->start();
  BLEAdvertising* advertising = BLEDevice::getAdvertising();
  advertising->addServiceUUID(NUS_SERVICE_UUID);
  advertising->addServiceUUID(FFE0_SERVICE_UUID);
  advertising->setScanResponse(true);
  BLEDevice::startAdvertising();
  Serial.println("RyzMusical ESP32 siap");
}

void loop(){
  server.handleClient();
  xSemaphoreTake(player.lock, portMAX_DELAY);
  if(player.playing && !player.paused && player.loaded){
    uint64_t pos = player.startUs + (uint64_t)((micros() - player.wallStart) * player.mult);
    while(player.cursor < player.events.size() && player.events[player.cursor].us <= pos){
      MidiEvent ev = player.events[player.cursor];
      player.cursor++;
      if(ev.type == 1){
        if(ev.note < 128) activeNotes[ev.note] = ev.vel;
      }else if(ev.type == 0){
        if(ev.note < 128) activeNotes[ev.note] = -1;
      }
    }
    refreshBuzzer();
    if(pos >= player.durationUs && player.cursor >= player.events.size()){
      stopPlaybackLocked();
      clearActiveNotes();
    }
  }
  xSemaphoreGive(player.lock);
  delay(2);
}
