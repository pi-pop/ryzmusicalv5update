(function(){
  var memoryStore = {};
  var storageOk = false;
  try{
    var testKey = '__ryzzStorageTest__';
    window.localStorage.setItem(testKey, '1');
    window.localStorage.removeItem(testKey);
    storageOk = true;
  }catch(e){ storageOk = false; }
  if(!storageOk){
    var fallback = {
      getItem: function(key){ return Object.prototype.hasOwnProperty.call(memoryStore, key) ? memoryStore[key] : null; },
      setItem: function(key, value){ memoryStore[key] = String(value); },
      removeItem: function(key){ delete memoryStore[key]; },
      clear: function(){ memoryStore = {}; },
      key: function(index){ return Object.keys(memoryStore)[index] || null; }
    };
    Object.defineProperty(fallback, 'length', { get: function(){ return Object.keys(memoryStore).length; } });
    try{
      Object.defineProperty(window, 'localStorage', { value: fallback, writable: true, configurable: true });
    }catch(e){
      try{ window.localStorage = fallback; }catch(e2){}
    }
  }
})();
(function(){
  if(typeof window.Tone !== 'undefined') return;
  var noop = function(){};
  var stubSynth = {
    toDestination: function(){ return this; },
    triggerAttackRelease: noop,
    dispose: noop,
    volume: { value: 0 }
  };
  window.Tone = {
    PolySynth: function(){ return stubSynth; },
    Synth: function(){},
    Sampler: function(opts){
      if(opts && typeof opts.onerror === 'function') setTimeout(opts.onerror, 0);
      return stubSynth;
    },
    Transport: {
      bpm: { value: 120 },
      start: noop,
      stop: noop,
      pause: noop,
      cancel: noop,
      position: 0,
      schedule: function(){ return 0; },
      scheduleOnce: function(){ return 0; }
    },
    Draw: { schedule: noop },
    Frequency: function(){ return { toNote: function(){ return ''; } }; },
    start: function(){ return Promise.resolve(); }
  };
})();
(function(){
  if(typeof window.Midi === 'undefined'){
    window.Midi = function(){
      return { header: { tempos: [] }, tracks: [] };
    };
  }
  if(typeof window.fflate === 'undefined'){
    window.fflate = { unzipSync: function(){ return {}; } };
  }
})();
document.addEventListener('click', function(e){
  if(e.target.classList && e.target.classList.contains('modal-overlay') && e.target.classList.contains('open')){
    e.target.classList.remove('open');
  }
  if(e.target.id === 'logoutConfirmBackdrop' && e.target.classList.contains('show')){
    e.target.classList.remove('show');
  }
});
let files = [];
let moduleMode = false;
let moduleBaseUrl = '';
let moduleTransport = 'wifi';
var SESSION_KEY = 'ryzzAccountId';
let websiteFilesBackup = null;
let websiteIdxBackup = 0;
let websiteVizBackup = null;
let appReady = false;
let tempoMult = 1;
let ctlPollTimer = null;
let ctlNotesTimer = null;
let ctlPollBusy = false;
let ctlNotesBusy = false;
let ctlOnline = null;
let ctlLoaded = false;
let ctlLastCount = -1;
let ctlWasPlaying = false;
let ctlLastRemain = 0;
let ctlUserStop = false;
let ctlDraggingVolume = false;
let ctlActiveNotes = new Set();
let hbLastBase = '';
let idx = 0;
let playing = false;
let paused = false;
let timerInterval;
let midiReady = false;
let bpm = 130;
let currentTime = 0;
let songDuration = 0;
let searchQuery = '';
let shuffleOn = false;
let repeatMode = 'off';
let isSeeking = false;
let customBgImage = null;
let ryzzAutoLockEnabled = true;
let ryzzAutoLockTimer = null;
let currentAccentColor = '#c81717';
let selectMode = false;
let selectedIndices = new Set();
const audioPlayer = new Audio();
audioPlayer.preload = 'auto';
audioPlayer.style.display = 'none';
document.body.appendChild(audioPlayer);
audioPlayer.onended = () => onSongEnded();

function arrayBufferToBase64(buffer){
  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunkSize = 0x8000;
  for(let i=0; i<bytes.length; i+=chunkSize){
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i+chunkSize));
  }
  return btoa(binary);
}

function base64ToUint8Array(base64){
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for(let i=0; i<binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function guessMime(name){
  const ext = name.split('.').pop().toLowerCase();
  const map = {mp3:'audio/mpeg', wav:'audio/wav', ogg:'audio/ogg', oga:'audio/ogg', m4a:'audio/mp4', aac:'audio/aac', flac:'audio/flac', opus:'audio/opus', webm:'audio/webm', flm:'application/octet-stream'};
  return map[ext] || 'audio/mpeg';
}

function getAudioDuration(url){
  return new Promise(resolve=>{
    const a = new Audio();
    a.preload = 'metadata';
    a.onloadedmetadata = () => resolve(a.duration || 0);
    a.onerror = () => resolve(0);
    a.src = url;
  });
}

function dbToLinear(db){
  return Math.min(1, Math.max(0, Math.pow(10, db/20)));
}

const RYZ_XOR_KEY = 'RYZ123';
const RYZ_HEADER_LEN = 12;

function xorWithKey(bytes, key){
  const keyBytes = new Uint8Array(key.length);
  for(let i=0;i<key.length;i++) keyBytes[i] = key.charCodeAt(i);
  const out = new Uint8Array(bytes.length);
  for(let i=0;i<bytes.length;i++) out[i] = bytes[i] ^ keyBytes[i % keyBytes.length];
  return out;
}
function hasMThdMagic(bytes){
  return bytes.length >= 4 && bytes[0]===0x4D && bytes[1]===0x54 && bytes[2]===0x68 && bytes[3]===0x64;
}
function decodeRyzBytes(input){
  const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
  if(bytes.length > RYZ_HEADER_LEN && bytes[0]===0x4E && bytes[1]===0x59 && bytes[2]===0x4F){
    const body = bytes.subarray(RYZ_HEADER_LEN);
    const decoded = xorWithKey(body, RYZ_XOR_KEY);
    if(hasMThdMagic(decoded)) return decoded.buffer;
  }
  const decodedRaw = xorWithKey(bytes, RYZ_XOR_KEY);
  if(hasMThdMagic(decodedRaw)) return decodedRaw.buffer;
  return null;
}

function expandZipEntries(arrayBuffer){
  const out = [];
  if(!window.fflate) return out;
  let unzipped;
  try{ unzipped = fflate.unzipSync(new Uint8Array(arrayBuffer)); }
  catch(e){ console.error('Gagal membuka ZIP:', e); return out; }
  for(const path in unzipped){
    const base = path.split('/').pop();
    if(!base) continue;
    const bytes = unzipped[path];
    if(!bytes || !bytes.length) continue;
    if(/\.ryz$/i.test(base)){
      const buf = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
      const dec = decodeRyzBytes(buf);
      if(!dec) continue;
      out.push({ name: base, buf: dec, isMidi: true });
    } else if(/\.(mid|midi)$/i.test(base)){
      out.push({ name: base, buf: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength), isMidi: true });
    } else if(AUDIO_EXT_RE.test(base)){
      out.push({ name: base, buf: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength), isMidi: false });
    }
  }
  return out;
}

async function expandFileList(fileList){
  const out = [];
  for(const f of fileList){
    const lower = f.name.toLowerCase();
    if(lower.endsWith('.zip')){
      try{
        const buf = await f.arrayBuffer();
        out.push(...expandZipEntries(buf));
      }catch(e){ console.error('Gagal membaca ZIP:', f.name, e); }
      continue;
    }
    if(lower.endsWith('.ryz')){
      try{
        const buf = await f.arrayBuffer();
        const dec = decodeRyzBytes(buf);
        if(dec) out.push({ name: f.name, buf: dec, isMidi: true });
        else console.error('File .ryz tidak valid / kunci tidak cocok:', f.name);
      }catch(e){ console.error('Gagal membaca RYZ:', f.name, e); }
      continue;
    }
    try{
      const buf = await f.arrayBuffer();
      out.push({ name: f.name, buf, isMidi: /\.(mid|midi)$/i.test(f.name) });
    }catch(e){ console.error('Gagal membaca file:', f.name, e); }
  }
  return out;
}

window.addEventListener('load', async () => {
  try{
    midiReady = true;
    customBgImage = localStorage.getItem('ryzzBgImage');
    currentAccentColor = localStorage.getItem('ryzzAccentColor') || '#c81717';
    applyBackground();
    const savedSampleAudio = localStorage.getItem('ryzzSampleAudio');
    if(savedSampleAudio){
      const savedBase = localStorage.getItem('ryzzSampleBaseNote') || DEFAULT_SAMPLE_BASE_NOTE;
      const savedName = localStorage.getItem('ryzzSampleName') || 'sample.mp3';
      loadCustomSample(savedSampleAudio, savedBase, savedName);
    }
    await loadBuiltinLibrary();
    await loadSavedMidi();
    initDoremi();
    initVisualizer();
    startTitleMarqueeLoop();
    initWarna();
    document.getElementById('volume').dispatchEvent(new Event('input'));
  }catch(e){
    console.error('Inisialisasi awal gagal sebagian:', e);
  }
  appReady = true;
  hbRestoreSession();
  try{ prfRefreshFromSession(); }catch(e){}
})

const AUDIO_EXT_RE = /\.(mp3|wav|ogg|oga|m4a|aac|flac|opus|webm|flm)$/i;
async function loadBuiltinLibrary(){
  const dataEl = document.getElementById('ryzzLibraryData');
  if(!dataEl || !window.fflate) return;
  const raw = dataEl.textContent.trim();
  if(!raw) return;
  try{
    const zipBytes = base64ToUint8Array(raw);
    const unzipped = fflate.unzipSync(zipBytes);
    const deleted = new Set(JSON.parse(localStorage.getItem('ryzzBuiltinDeleted') || '[]'));
    const builtinFiles = [];
    for(const path in unzipped){
      let base = path.split('/').pop();
      if(!base) continue;
      const isRyz = /\.ryz$/i.test(base);
      let isMidi = /\.(mid|midi)$/i.test(base);
      const isAudio = !isRyz && AUDIO_EXT_RE.test(base);
      if(!isMidi && !isAudio && !isRyz) continue;
      const bytes = unzipped[path];
      let buf = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
      if(isRyz){
        const dec = decodeRyzBytes(buf);
        if(!dec) continue;
        buf = dec;
        isMidi = true;
      }
      if(deleted.has(base)) continue;
      const base64 = arrayBufferToBase64(buf);
      if(isMidi){
        let midi;
        try{ midi = new Midi(buf); }
        catch(e){ continue; }
        builtinFiles.push({ name: base, origName: base, type:'midi', midi, base64, builtin:true, addedAt:0 });
      } else {
        const mime = guessMime(base);
        const dataUrl = `data:${mime};base64,${base64}`;
        let duration = 0;
        try{ duration = await getAudioDuration(dataUrl); }catch(e){ duration = 0; }
        builtinFiles.push({ name: base, origName: base, type:'audio', mime, base64, duration, builtin:true, undecodable: !duration, addedAt:0 });
      }
    }
    builtinFiles.sort((a,b)=> a.origName.localeCompare(b.origName, undefined, {numeric:true}));
    files.push(...builtinFiles);
  }catch(e){ console.error('Gagal memuat library bawaan:', e); }
}

function hexToRgbArr(hex){
  hex = hex.replace('#', '');
  if(hex.length === 3) hex = hex.split('').map(c => c + c).join('');
  const num = parseInt(hex, 16);
  return [(num >> 16) & 255, (num >> 8) & 255, num & 255];
}
function mixRgb(rgb, target, amount){
  return rgb.map((c, i) => Math.round(c + (target[i] - c) * amount));
}
function applyAccentTheme(hex){
  const base = hexToRgbArr(hex);
  const strong = mixRgb(base, [0, 0, 0], 0.14);
  const light = mixRgb(base, [255, 255, 255], 0.32);
  const lightest = mixRgb(base, [255, 255, 255], 0.58);
  const root = document.documentElement.style;
  root.setProperty('--accent-rgb', base.join(','));
  root.setProperty('--accent-strong-rgb', strong.join(','));
  root.setProperty('--accent-light-rgb', light.join(','));
  root.setProperty('--accent-lightest-rgb', lightest.join(','));
}
function applyBackground(){
  applyAccentTheme(currentAccentColor);
  const bgImage = customBgImage || 'https://raw.githubusercontent.com/pi-pop/bg/main/bg.png';
  document.body.style.background = `url('${bgImage}') center/cover no-repeat fixed`;
}

document.getElementById('menuBtn').onclick = () => {
  document.getElementById('menuDropdown').classList.toggle('open');
}
const TAB_LABELS = { main:'MENU', doremi:'DOREMI', tampilan:'TAMPILAN', suara:'SUARA', sanding:'HUBUNGKAN', profil:'PROFIL' };
document.querySelectorAll('.menu-dropdown button[data-tab]').forEach(btn=>{
  btn.onclick = () => {
    document.querySelectorAll('.tab-content').forEach(c=>{ c.classList.remove('active'); c.classList.remove('show'); });
    const next = document.getElementById('tab-'+btn.dataset.tab);
    next.classList.add('active');
    requestAnimationFrame(()=> requestAnimationFrame(()=> next.classList.add('show')));
    document.getElementById('menuDropdown').classList.remove('open');
    document.getElementById('menuBtn').innerHTML = (TAB_LABELS[btn.dataset.tab] || 'MENU') + ' ▾';
    if(btn.dataset.tab === 'suara') refreshAdvSettingsUI();
    if(btn.dataset.tab === 'profil') prfRefreshFromSession();
  }
})

const BASS_THRESHOLD_MIDI = 48;
let bassHardness = localStorage.getItem('ryzzBassHardness') || 'hard';

function makeSilentSynthFallback(){
  return {
    volume: { value: 0 },
    maxPolyphony: 0,
    toDestination(){ return this; },
    triggerAttack(){},
    triggerRelease(){},
    triggerAttackRelease(){},
    releaseAll(){},
    dispose(){},
    set(){}
  };
}
function buildTrebleSynth(){
  try{
    return new Tone.PolySynth(Tone.Synth, {
      oscillator: { type: 'square' },
      envelope: { attack: 0.006, decay: 0.001, sustain: 1, release: 0.09 },
      volume: -16
    }).toDestination();
  }catch(e){
    return makeSilentSynthFallback();
  }
}
function buildBassSynth(hardness){
  const wave = hardness === 'soft' ? 'triangle' : 'square';
  const env = hardness === 'soft'
    ? { attack: 0.02, decay: 0.06, sustain: 0.8, release: 0.18 }
    : { attack: 0.006, decay: 0.001, sustain: 1, release: 0.09 };
  try{
    return new Tone.PolySynth(Tone.Synth, { oscillator: { type: wave }, envelope: env, volume: -14 }).toDestination();
  }catch(e){
    return makeSilentSynthFallback();
  }
}

let trebleSynth = buildTrebleSynth();
trebleSynth.maxPolyphony = 18;
let bassSynth = buildBassSynth(bassHardness);
bassSynth.maxPolyphony = 18;
let customSample = null;
let customSampleLoaded = false;
let customSampleName = null;

function setBassHardness(h){
  bassHardness = h;
  localStorage.setItem('ryzzBassHardness', h);
  const oldBass = bassSynth;
  bassSynth = buildBassSynth(h);
  bassSynth.maxPolyphony = 18;
  applyVolumeWithOffsets();
  oldBass.dispose();
}

const DYNAMIC_OFFSETS = {
  normal: { bass: 0, treble: 0 },
  bassSoftTrebleLoud: { bass: -8, treble: 8 },
  bassLoudTrebleSoft: { bass: 8, treble: -8 }
};
let dynamicMode = localStorage.getItem('ryzzDynamicMode') || 'normal';
function applyVolumeWithOffsets(){
  const db = parseFloat(document.getElementById('volume').value);
  const off = DYNAMIC_OFFSETS[dynamicMode] || DYNAMIC_OFFSETS.normal;
  trebleSynth.volume.value = db + off.treble;
  bassSynth.volume.value = db + off.bass;
  if(customSample) customSample.volume.value = db;
  audioPlayer.volume = dbToLinear(db);
}
function applyDynamicMode(mode){
  dynamicMode = mode;
  localStorage.setItem('ryzzDynamicMode', mode);
  if(mode === 'bassSoftTrebleLoud') setBassHardness('soft');
  else if(mode === 'bassLoudTrebleSoft') setBassHardness('hard');
  else applyVolumeWithOffsets();
  refreshAdvSettingsUI();
}

function loadCustomSample(dataUrl, baseNote, name){
  return new Promise((resolve) => {
    customSampleLoaded = false;
    const vol = parseFloat(document.getElementById('volume').value);
    const s = new Tone.Sampler({
      urls: { [baseNote]: dataUrl },
      release: 0.3,
      volume: vol,
      onload: () => { customSampleLoaded = true; resolve(true); },
      onerror: () => { resolve(false); }
    }).toDestination();
    customSample = s;
    customSampleName = name;
  });
}

function getEngineForNote(midiNum){
  if(customSample && customSampleLoaded) return customSample;
  if(midiNum !== undefined && midiNum !== null && midiNum < BASS_THRESHOLD_MIDI) return bassSynth;
  return trebleSynth;
}
function triggerNote(noteName, duration, time, velocity, midiNum){
  getEngineForNote(midiNum).triggerAttackRelease(noteName, duration, time, velocity);
}

try{ Tone.Transport.bpm.value = bpm; }catch(e){}
document.getElementById('volume').oninput = () => {
  ctlDraggingVolume = moduleMode;
  applyVolumeWithOffsets();
};
document.getElementById('volume').addEventListener('change', e => {
  ctlDraggingVolume = false;
  if(moduleMode) ctlPost('/api/volume?v=' + Math.round((parseFloat(e.target.value) + 20) / 20 * 100));
});

document.getElementById('tempoUp').onclick = () => { if(moduleMode){ ctlTempo(0.05); return; } if(bpm < 500) { bpm += 5; setTempo(); } }
document.getElementById('tempoDown').onclick = () => { if(moduleMode){ ctlTempo(-0.05); return; } if(bpm > 10) { bpm -= 5; setTempo(); } }
function setTempo(){ Tone.Transport.bpm.value = bpm; document.getElementById('tempo').innerText = bpm; }

let fbApp = null;
let fbDb = null;
let fbUnsub = null;
const FB_COLLECTION = 'midi_songs';
function getCloudHidden(){ return new Set(JSON.parse(localStorage.getItem('ryzzCloudHidden') || '[]')); }

const RYZZ_SONGS_CACHE_KEY = 'ryzzSongsCache';
function ryzzSaveSongsCache(){
  try{
    const payload = files.filter(f => f.cloud).map(f => ({
      name: f.name,
      type: f.type,
      data: f.base64,
      mime: f.mime || null,
      duration: f.duration || 0,
      cloudId: f.cloudId,
      addedAtMs: f.addedAt
    }));
    localStorage.setItem(RYZZ_SONGS_CACHE_KEY, JSON.stringify(payload));
  }catch(e){}
}
function ryzzLoadSongsCache(){
  let raw = null;
  try{ raw = localStorage.getItem(RYZZ_SONGS_CACHE_KEY); }catch(e){ raw = null; }
  if(!raw) return [];
  let list;
  try{ list = JSON.parse(raw); }catch(e){ return []; }
  if(!Array.isArray(list)) return [];
  const hidden = getCloudHidden();
  const out = [];
  list.forEach(data => {
    if(hidden.has(data.cloudId)) return;
    if(data.type === 'midi'){
      let midi;
      try{ midi = new Midi(base64ToUint8Array(data.data).buffer); }
      catch(e){ return; }
      out.push({ name:data.name, type:'midi', midi, base64:data.data, cloud:true, cloudId:data.cloudId, addedAt:data.addedAtMs });
    } else {
      out.push({ name:data.name, type:'audio', base64:data.data, mime:data.mime, duration:data.duration||0, cloud:true, cloudId:data.cloudId, addedAt:data.addedAtMs });
    }
  });
  out.sort((a,b) => (a.addedAt||0) - (b.addedAt||0));
  return out;
}

function connectFirebase(configStr){
  let config;
  try{ config = JSON.parse(configStr); }
  catch(e){ return; }
  try{
    if(fbUnsub){ fbUnsub(); fbUnsub = null; }
    if(fbApp){ try{ firebase.app().delete(); }catch(e){} }
    fbApp = firebase.initializeApp(config);
    fbDb = firebase.firestore();
    fbDb.settings({ experimentalAutoDetectLongPolling: true, merge: true });
    fbDb.enablePersistence({ synchronizeTabs: true }).catch(err => {
      console.warn('Cache offline Firestore tidak aktif:', err.code);
    });
    const hidden = getCloudHidden();
    const applyCloud = snapshot => {
      let changed = false;
      snapshot.docChanges().forEach(change => {
        const doc = change.doc;
        const data = doc.data();
        if(change.type === 'removed'){
          const before = files.length;
          files = files.filter(f => !(f.cloud && f.cloudId === doc.id));
          if(files.length !== before) changed = true;
          return;
        }
        if(hidden.has(doc.id)) return;
        const addedAtMs = data.addedAt && data.addedAt.toMillis ? data.addedAt.toMillis() : Date.now();
        const existingIdx = files.findIndex(f => f.cloud && f.cloudId === doc.id);
        let entry;
        if(data.type === 'midi'){
          let midi;
          try{ midi = new Midi(base64ToUint8Array(data.data).buffer); }
          catch(e){ return; }
          entry = { name:data.name, type:'midi', midi, base64:data.data, cloud:true, cloudId:doc.id, addedAt:addedAtMs };
        } else {
          entry = { name:data.name, type:'audio', base64:data.data, mime:data.mime, duration:data.duration||0, cloud:true, cloudId:doc.id, addedAt:addedAtMs };
        }
        if(existingIdx >= 0) files[existingIdx] = entry;
        else insertSorted(entry);
        changed = true;
      });
      if(changed) ryzzSaveSongsCache();
      if(changed && !moduleMode){ renderList(); updateNowInfo(); }
    };
    fbUnsub = fbDb.collection(FB_COLLECTION).orderBy('addedAt', 'asc').onSnapshot(snapshot => {
      if(!moduleMode){ applyCloud(snapshot); return; }
      const ctlFiles = files;
      const ctlIdx = idx;
      files = websiteFilesBackup;
      idx = websiteIdxBackup;
      applyCloud(snapshot);
      websiteFilesBackup = files;
      websiteIdxBackup = idx;
      files = ctlFiles;
      idx = ctlIdx;
    }, err => {
      console.error('Firestore error:', err);
    });
  }catch(e){
    console.error(e);
  }
}

const DEFAULT_FIREBASE_CONFIG = JSON.stringify({
  apiKey: "AIzaSyDpRllLIJ346sw9FNM0KF7H1B_HAftAIkI",
  authDomain: "ryzmusical.firebaseapp.com",
  projectId: "ryzmusical",
  storageBucket: "ryzmusical.firebasestorage.app",
  messagingSenderId: "934193972979",
  appId: "1:934193972979:web:a31ffe822e7d2e9fd8d986",
  measurementId: "G-80WXWJD34L"
});
const ryzzCachedSongs = ryzzLoadSongsCache();
if(ryzzCachedSongs.length){
  files = ryzzCachedSongs;
  renderList();
  updateNowInfo();
}
connectFirebase(DEFAULT_FIREBASE_CONFIG);

function transposeNote(noteName) { return noteName; }

const TITLE_MARQUEE_REST_MS = 3000;
const TITLE_MARQUEE_PAUSE_HOLD_MS = 1000;
const TITLE_MARQUEE_SPEED_PX_MS = 0.035;
const titleMarquee = { mode: null, phase: 'rest', pos: 0, restLeft: 0, holdUntil: 0, last: 0 };
function titleMarqueeMode(){
  if(paused) return 'pause';
  return playing ? 'play' : 'stop';
}
function resetTitleMarquee(){
  titleMarquee.mode = null;
  titleMarquee.phase = 'rest';
  titleMarquee.pos = 0;
  titleMarquee.restLeft = 0;
  titleMarquee.holdUntil = 0;
  const inner = document.getElementById('nowTitleInner');
  if(inner) inner.style.transform = 'translateX(0px)';
}
function startTitleMarqueeLoop(){
  const m = titleMarquee;
  function step(now){
    requestAnimationFrame(step);
    const dt = Math.min(now - (m.last || now), 100);
    m.last = now;
    const container = document.getElementById('nowTitle');
    const inner = document.getElementById('nowTitleInner');
    if(!container || !inner) return;
    const areaWidth = container.clientWidth;
    const textWidth = inner.scrollWidth;
    const mode = titleMarqueeMode();
    if(mode !== m.mode){
      m.mode = mode;
      if(mode === 'stop'){
        m.phase = 'rest';
        m.pos = 0;
        m.restLeft = 0;
        m.holdUntil = 0;
      } else if(mode === 'play'){
        m.holdUntil = 0;
        if(m.phase === 'rest') m.restLeft = 0;
      } else {
        m.holdUntil = now + TITLE_MARQUEE_PAUSE_HOLD_MS;
        if(m.phase === 'rest') m.restLeft = 0;
      }
    }
    if(mode === 'stop' || textWidth <= areaWidth){
      m.phase = 'rest';
      m.pos = 0;
      m.restLeft = 0;
      inner.style.transform = 'translateX(0px)';
      return;
    }
    if(now >= m.holdUntil){
      if(m.phase === 'rest'){
        m.restLeft -= dt;
        if(m.restLeft <= 0) m.phase = 'out';
      } else if(m.phase === 'out'){
        m.pos -= dt * TITLE_MARQUEE_SPEED_PX_MS;
        if(m.pos <= -textWidth){
          m.phase = 'in';
          m.pos = areaWidth;
        }
      } else {
        m.pos -= dt * TITLE_MARQUEE_SPEED_PX_MS;
        if(m.pos <= 0){
          m.pos = 0;
          m.phase = 'rest';
          m.restLeft = TITLE_MARQUEE_REST_MS;
        }
      }
    }
    inner.style.transform = 'translateX(' + m.pos + 'px)';
  }
  requestAnimationFrame(step);
}

function formatTime(sec){
  sec = Math.max(0, Math.floor(sec || 0));
  let m = String(Math.floor(sec/60)).padStart(2,'0');
  let s = String(sec%60).padStart(2,'0');
  return `${m}:${s}`;
}

const NOTE_RANGE_MIN = 12;
const NOTE_RANGE_MAX = 143;
const DOREMI_DEFAULT_START = 29;
const DOREMI_DEFAULT_END = 88;
let doremiStart = DOREMI_DEFAULT_START;
let doremiEnd = DOREMI_DEFAULT_END;

function midiNoteName(m){ return Tone.Frequency(m, "midi").toNote(); }

function populateNoteRangeSelects(){
  const startSel = document.getElementById('noteRangeStart');
  const endSel = document.getElementById('noteRangeEnd');
  startSel.innerHTML = ''; endSel.innerHTML = '';
  for(let m=NOTE_RANGE_MIN; m<=NOTE_RANGE_MAX; m++){
    const name = midiNoteName(m);
    const o1 = document.createElement('option'); o1.value = String(m); o1.innerText = name; startSel.appendChild(o1);
    const o2 = document.createElement('option'); o2.value = String(m); o2.innerText = name; endSel.appendChild(o2);
  }
  startSel.value = String(doremiStart);
  endSel.value = String(doremiEnd);
}

function updateDoremiRangeInfo(){
  document.getElementById('noteRangeShowing').innerText = 'Menampilkan ' + midiNoteName(doremiStart) + ' \u2192 ' + midiNoteName(doremiEnd);
  document.getElementById('noteRangeCount').innerText = 'Jumlah Not: ' + (doremiEnd - doremiStart + 1);
}

function initDoremi(){
  const grid = document.getElementById('doremiGrid');
  grid.innerHTML = '';
  for(let midiNote=doremiStart; midiNote<=doremiEnd; midiNote++){
    const noteName = midiNoteName(midiNote);
    const btn = document.createElement('div');
    btn.className = 'doremi-btn' + (noteName.includes('#')? ' black' : '');
    btn.innerText = noteName;
    btn.onclick = () => { if(!moduleMode) triggerNote(noteName, "8n", undefined, 1, midiNote); };
    let held = false;
    const noteOn = ev => {
      if(!moduleMode) return;
      ev.preventDefault();
      held = true;
      ctlPost('/api/testnote?note=' + midiNote + '&on=1');
    };
    const noteOff = () => {
      if(!held) return;
      held = false;
      ctlPost('/api/testnote?note=' + midiNote + '&on=0');
    };
    btn.addEventListener('pointerdown', noteOn);
    btn.addEventListener('pointerup', noteOff);
    btn.addEventListener('pointerleave', noteOff);
    btn.addEventListener('pointercancel', noteOff);
    grid.appendChild(btn);
  }
  populateNoteRangeSelects();
  updateDoremiRangeInfo();
}

document.getElementById('noteRangeApplyBtn').onclick = () => {
  let s = parseInt(document.getElementById('noteRangeStart').value, 10);
  let e = parseInt(document.getElementById('noteRangeEnd').value, 10);
  if(isNaN(s) || isNaN(e)) return;
  if(s > e){ const t = s; s = e; e = t; }
  doremiStart = s; doremiEnd = e;
  initDoremi();
};
document.getElementById('noteRangeResetBtn').onclick = () => {
  doremiStart = DOREMI_DEFAULT_START;
  doremiEnd = DOREMI_DEFAULT_END;
  initDoremi();
};

let vizMinNote = 29;
let vizMaxNote = 88;
let vizBarCount = parseInt(localStorage.getItem('ryzzBarCount'), 10) || 60;
let visualizerBars = [];
let visualizerPeaks = [];
function initVisualizer(){
  setBarCount(vizBarCount);
}
function setBarCount(n){
  vizBarCount = Math.max(4, Math.min(200, n));
  localStorage.setItem('ryzzBarCount', vizBarCount);
  const container = document.getElementById('noteVisualizer');
  container.innerHTML = '';
  visualizerBars = [];
  visualizerPeaks = [];
  for(let i=0; i<vizBarCount; i++){
    const bar = document.createElement('div');
    bar.className = 'nv-bar';
    const peak = document.createElement('div');
    peak.className = 'nv-peak';
    bar.appendChild(peak);
    container.appendChild(bar);
    visualizerBars.push(bar);
    visualizerPeaks.push(peak);
  }
}
function computeVizRangeForMidi(midi){
  let lo = Infinity, hi = -Infinity;
  midi.tracks.forEach(track => track.notes.forEach(n => {
    if(n.midi < lo) lo = n.midi;
    if(n.midi > hi) hi = n.midi;
  }));
  if(lo === Infinity){ vizMinNote = 29; vizMaxNote = 88; return; }
  vizMinNote = lo;
  vizMaxNote = Math.max(hi, lo + 1);
}
function barIndexForNote(midiNote){
  const span = vizMaxNote - vizMinNote;
  const maxIdx = visualizerBars.length - 1;
  if(maxIdx <= 0) return 0;
  if(span <= maxIdx) return Math.round(midiNote - vizMinNote);
  return Math.round((midiNote - vizMinNote) / span * maxIdx);
}
function setBarActive(midiNote, on, velocity){
  const i = barIndexForNote(midiNote);
  if(i < 0 || i >= visualizerBars.length) return;
  const bar = visualizerBars[i];
  const peak = visualizerPeaks[i];
  if(on){
    const h = 22 + Math.max(0, Math.min(1, velocity)) * 78;
    bar.style.height = h + '%';
    peak.style.bottom = h + '%';
    bar.classList.add('on');
    peak.classList.add('on');
  } else {
    bar.style.height = '6%';
    peak.style.bottom = '6%';
    bar.classList.remove('on');
    peak.classList.remove('on');
  }
}
function resetVisualizer(){
  visualizerBars.forEach((b, i) => {
    b.style.height = '6%';
    b.classList.remove('on');
    visualizerPeaks[i].style.bottom = '6%';
    visualizerPeaks[i].classList.remove('on');
  });
}

function initWarna(){
  const colors = [
    '#000000', '#1a1a2e', '#16213e', '#0f3460', '#533483', '#e94560',
    '#ff9a00', '#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#ffeaa7',
    '#fd79a8', '#fdcb6e', '#6c5ce7', '#a29bfe', '#74b9ff', '#55efc4'
  ];
  const grid = document.getElementById('colorGrid');
  const savedIndex = parseInt(localStorage.getItem('ryzzAccentColorIndex'), 10);
  colors.forEach((color, i)=>{
    const btn = document.createElement('div');
    btn.className = 'color-btn';
    btn.style.background = color;
    btn.onclick = () => {
      document.querySelectorAll('.color-btn').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      currentAccentColor = color;
      localStorage.setItem('ryzzAccentColor', color);
      localStorage.setItem('ryzzAccentColorIndex', i);
      document.getElementById('customColorPicker').value = color;
      applyBackground();
      ryzzSyncThemeToAccount();
    }
    grid.appendChild(btn);
    if(i === (isNaN(savedIndex) ? 0 : savedIndex)) btn.classList.add('active');
  })
}

document.getElementById('customColorPicker').value = localStorage.getItem('ryzzAccentColor') || '#c81717';
document.getElementById('customColorPicker').oninput = e => {
  localStorage.setItem('ryzzAccentMode', 'solid');
  document.querySelectorAll('.color-btn').forEach(b => b.classList.remove('active'));
  localStorage.removeItem('ryzzAccentColorIndex');
  currentAccentColor = e.target.value;
  localStorage.setItem('ryzzAccentColor', currentAccentColor);
  applyBackground();
  ryzzSyncThemeToAccount();
};

const DEFAULT_SAMPLE_BASE_NOTE = 'C4';

function refreshAdvSettingsUI(){
  document.getElementById('sampleStatus').innerText = customSampleName ? ('Aktif: ' + customSampleName) : 'Memakai synth bawaan';
  document.getElementById('bassHardBtn').classList.toggle('active-toggle', bassHardness === 'hard' && dynamicMode === 'normal');
  document.getElementById('bassSoftBtn').classList.toggle('active-toggle', bassHardness === 'soft' && dynamicMode === 'normal');
  document.getElementById('dynModeABtn').classList.toggle('active-toggle', dynamicMode === 'bassSoftTrebleLoud');
  document.getElementById('dynModeBBtn').classList.toggle('active-toggle', dynamicMode === 'bassLoudTrebleSoft');
  document.getElementById('dynModeNormalBtn').classList.toggle('active-toggle', dynamicMode === 'normal');
  document.getElementById('barCountRange').value = vizBarCount;
  document.getElementById('barCountVal').innerText = vizBarCount;
}

document.getElementById('sampleUploadZone').onclick = () => document.getElementById('sampleFile').click();
async function processSampleFile(f){
  if(!f) return;
  document.getElementById('sampleStatus').innerText = 'Memuat sample...';
  const buf = await f.arrayBuffer();
  const base64 = arrayBufferToBase64(buf);
  const isFlm = /\.flm$/i.test(f.name);
  const mime = f.type || (isFlm ? 'application/octet-stream' : 'audio/mpeg');
  const dataUrl = `data:${mime};base64,${base64}`;
  const baseNote = DEFAULT_SAMPLE_BASE_NOTE;
  const ok = await loadCustomSample(dataUrl, baseNote, f.name);
  if(!ok){
    customSample = null;
    customSampleLoaded = false;
    customSampleName = null;
    if(isFlm){
      alert('File .flm ini adalah project FL Studio Mobile (bukan file audio biasa), jadi isinya tidak bisa langsung dipakai sebagai sample suara. Export dulu suaranya jadi file WAV/MP3 dari FL Studio Mobile, baru upload hasil export-nya di sini.');
    } else {
      alert('Gagal memuat file ini sebagai sample suara. Pastikan filenya format audio yang didukung (MP3, WAV, OGG, dll).');
    }
    refreshAdvSettingsUI();
    return;
  }
  try {
    localStorage.setItem('ryzzSampleAudio', dataUrl);
    localStorage.setItem('ryzzSampleBaseNote', baseNote);
    localStorage.setItem('ryzzSampleName', f.name);
  } catch(err){
    alert('Sample berhasil dipakai untuk sesi ini, tapi ukurannya terlalu besar untuk disimpan permanen (akan kembali ke synth default kalau halaman di-reload).');
  }
  refreshAdvSettingsUI();
}
document.getElementById('sampleFile').onchange = async e => {
  const f = e.target.files[0];
  await processSampleFile(f);
  e.target.value = '';
}
const sampleDropZone = document.getElementById('sampleUploadZone');
sampleDropZone.ondragover = e => { e.preventDefault(); sampleDropZone.classList.add('dragover'); };
sampleDropZone.ondragleave = () => { sampleDropZone.classList.remove('dragover'); };
sampleDropZone.ondrop = async e => {
  e.preventDefault();
  sampleDropZone.classList.remove('dragover');
  const f = e.dataTransfer.files && e.dataTransfer.files[0];
  await processSampleFile(f);
}

document.getElementById('resetSuaraBtn').onclick = () => {
  customSample = null;
  customSampleLoaded = false;
  customSampleName = null;
  localStorage.removeItem('ryzzSampleAudio');
  localStorage.removeItem('ryzzSampleBaseNote');
  localStorage.removeItem('ryzzSampleName');
  setBassHardness('hard');
  applyDynamicMode('normal');
  setBarCount(60);
  refreshAdvSettingsUI();
}
document.getElementById('resetTampilanBtn').onclick = () => {
  currentAccentColor = '#c81717';
  customBgImage = null;
  ['ryzzAccentColor', 'ryzzAccentColorIndex', 'ryzzAccentMode', 'ryzzBgImage'].forEach(k => localStorage.removeItem(k));
  document.querySelectorAll('.color-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('customColorPicker').value = currentAccentColor;
  document.getElementById('bgFile').value = '';
  applyBackground();
  ryzzSyncThemeToAccount();
}

document.getElementById('bassHardBtn').onclick = () => { dynamicMode = 'normal'; localStorage.setItem('ryzzDynamicMode','normal'); setBassHardness('hard'); refreshAdvSettingsUI(); }
document.getElementById('bassSoftBtn').onclick = () => { dynamicMode = 'normal'; localStorage.setItem('ryzzDynamicMode','normal'); setBassHardness('soft'); refreshAdvSettingsUI(); }
document.getElementById('dynModeABtn').onclick = () => { applyDynamicMode('bassSoftTrebleLoud'); }
document.getElementById('dynModeBBtn').onclick = () => { applyDynamicMode('bassLoudTrebleSoft'); }
document.getElementById('dynModeNormalBtn').onclick = () => { applyDynamicMode('normal'); }

document.getElementById('barCountRange').oninput = e => {
  const n = parseInt(e.target.value, 10);
  document.getElementById('barCountVal').innerText = n;
  setBarCount(n);
}
document.getElementById('uploadZone').onclick = () => document.getElementById('bgFile').click();

document.getElementById('bgFile').onchange = e => {
  const f = e.target.files[0];
  if(!f) return;
  const reader = new FileReader();
  reader.onload = () => {
    customBgImage = reader.result;
    localStorage.setItem('ryzzBgImage', customBgImage);
    applyBackground();
    ryzzSyncThemeToAccount();
  };
  reader.readAsDataURL(f);
}

document.getElementById('hapusBtn').onclick = () => {
  if(files.length === 0) return;
  selectMode = true;
  selectedIndices = new Set(files.map((_,i)=>i));
  const btn = document.getElementById('selectModeBtn');
  btn.style.display = '';
  btn.classList.add('active');
  btn.innerText = 'BATAL';
  renderList();
  updateBulkDeleteUI();
}

document.getElementById('shuffleBtn').onclick = () => {
  shuffleOn = !shuffleOn;
  document.getElementById('shuffleBtn').classList.toggle('active-toggle', shuffleOn);
}

function updateRepeatButtonUI(){
  const btn = document.getElementById('repeatBtn');
  btn.classList.toggle('active-toggle', repeatMode !== 'off');
  btn.innerText = repeatMode === 'one' ? 'Repeat: 1' : 'Repeat';
}

document.getElementById('repeatBtn').onclick = () => {
  repeatMode = repeatMode === 'off' ? 'loop' : repeatMode === 'loop' ? 'one' : 'off';
  updateRepeatButtonUI();
}

const LOCAL_DB_NAME = 'ryzzLocalSongsDB';
const LOCAL_DB_STORE = 'songs';
let localDbPromise = null;
function openLocalDb(){
  if(localDbPromise) return localDbPromise;
  localDbPromise = new Promise((resolve, reject) => {
    if(!window.indexedDB){ reject(new Error('IndexedDB tidak didukung')); return; }
    const req = indexedDB.open(LOCAL_DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if(!db.objectStoreNames.contains(LOCAL_DB_STORE)){
        db.createObjectStore(LOCAL_DB_STORE, { keyPath: 'id' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return localDbPromise;
}
function genLocalId(){
  return 'l' + Date.now().toString(36) + Math.random().toString(36).slice(2, 9);
}
async function localDbPut(record){
  try{
    const db = await openLocalDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(LOCAL_DB_STORE, 'readwrite');
      tx.objectStore(LOCAL_DB_STORE).put(record);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    return true;
  }catch(err){
    console.error('Gagal menyimpan lagu ke penyimpanan lokal', err);
    return false;
  }
}
async function localDbDelete(id){
  if(!id) return;
  try{
    const db = await openLocalDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(LOCAL_DB_STORE, 'readwrite');
      tx.objectStore(LOCAL_DB_STORE).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }catch(err){
    console.error('Gagal menghapus lagu di penyimpanan lokal', err);
  }
}
async function localDbGetAll(){
  try{
    const db = await openLocalDb();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(LOCAL_DB_STORE, 'readonly');
      const req = tx.objectStore(LOCAL_DB_STORE).getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  }catch(err){
    console.error('Gagal membaca penyimpanan lokal', err);
    return [];
  }
}
async function migrateLegacyLocalStorageSongs(){
  const saved = localStorage.getItem('ryzzMidiList');
  if(!saved) return;
  try{
    const data = JSON.parse(saved);
    for(const item of data){
      const record = item.type === 'audio'
        ? { id: genLocalId(), name:item.name, type:'audio', data:item.data, mime:item.mime, duration:item.duration, addedAt:item.addedAt || 0 }
        : { id: genLocalId(), name:item.name, type:'midi', data:item.data, addedAt:item.addedAt || 0 };
      await localDbPut(record);
    }
  }catch(err){
    console.error('Gagal memindahkan lagu lama ke penyimpanan baru', err);
  }
  localStorage.removeItem('ryzzMidiList');
}

async function saveMidi(){
  const localFiles = files.filter(f => !f.builtin && !f.cloud);
  let ok = true;
  for(const f of localFiles){
    if(!f.localId) f.localId = genLocalId();
    const record = f.type === 'audio'
      ? { id:f.localId, name:f.name, type:'audio', data:f.base64, mime:f.mime, duration:f.duration, addedAt:f.addedAt }
      : { id:f.localId, name:f.name, type:'midi', data:f.base64, addedAt:f.addedAt };
    const put = await localDbPut(record);
    if(!put) ok = false;
  }
  return ok;
}

async function loadSavedMidi(){
  await migrateLegacyLocalStorageSongs();
  const records = await localDbGetAll();
  for(let item of records){
    if(item.type === 'audio'){
      files.push({name:item.name, type:'audio', base64:item.data, mime:item.mime, duration:item.duration, addedAt:item.addedAt || 0, localId:item.id});
    } else {
      const byteArray = base64ToUint8Array(item.data);
      const midi = new Midi(byteArray.buffer);
      files.push({name:item.name, type:'midi', midi, base64:item.data, addedAt:item.addedAt || 0, localId:item.id});
    }
  }
  renderList();
  updateNowInfo();
}

function openUploadProgress(total){
  document.getElementById('uploadSpinner').classList.remove('done');
  document.getElementById('uploadProgressTitle').innerText = 'Menambahkan lagu...';
  document.getElementById('uploadProgressCurrent').innerText = '';
  document.getElementById('uploadProgressCount').innerText = `${'0'.padStart(3,'0')} / ${String(total).padStart(3,'0')}`;
  document.getElementById('uploadProgressFill').style.width = '0%';
  document.getElementById('uploadProgressOverlay').classList.add('open');
}
function updateUploadProgress(cur, total, name){
  document.getElementById('uploadProgressCurrent').innerText = name;
  document.getElementById('uploadProgressCount').innerText = `${String(cur).padStart(3,'0')} / ${String(total).padStart(3,'0')}`;
  document.getElementById('uploadProgressFill').style.width = Math.round(cur/total*100) + '%';
}
function closeUploadProgress(added, total, saveOk){
  document.getElementById('uploadSpinner').classList.add('done');
  document.getElementById('uploadProgressTitle').innerText = 'Selesai';
  document.getElementById('uploadProgressCurrent').innerText = saveOk
    ? `${added} dari ${total} lagu berhasil ditambahkan`
    : `${added} lagu ditambahkan, tapi penyimpanan penuh (tidak permanen)`;
  document.getElementById('uploadProgressFill').style.width = '100%';
  setTimeout(() => { document.getElementById('uploadProgressOverlay').classList.remove('open'); }, 1100);
}

document.getElementById('file').onchange = async e=>{
  if(moduleMode) return ctlUpload(e);
  if(!midiReady) return alert('Tunggu 2 detik, library masih loading...');
  const rawList = Array.from(e.target.files);
  if(rawList.length === 0) return;
  const expanded = await expandFileList(rawList);
  if(expanded.length === 0){
    alert('Tidak ada lagu yang bisa dibaca dari file ini.');
    e.target.value = '';
    return;
  }
  const showProgress = expanded.length > 1;
  if(showProgress) openUploadProgress(expanded.length);

  let addedCount = 0;
  for(let k = 0; k < expanded.length; k++){
    const item = expanded[k];
    if(showProgress) updateUploadProgress(k+1, expanded.length, item.name);
    try {
      const base64 = arrayBufferToBase64(item.buf);
      if(item.isMidi){
        const midi = new Midi(item.buf);
        insertSorted({name:item.name, type:'midi', midi, base64, addedAt:Date.now()});
      } else {
        const mime = guessMime(item.name);
        const duration = await getAudioDuration(`data:${mime};base64,${base64}`);
        insertSorted({name:item.name, type:'audio', base64, mime, duration, addedAt:Date.now()});
      }
      addedCount++;
    } catch(err){
      console.error('Gagal menambah lagu', item.name, err);
    }
    await new Promise(requestAnimationFrame);
  }

  const saveOk = await saveMidi();
  renderList();
  updateNowInfo();
  if(showProgress) closeUploadProgress(addedCount, expanded.length, saveOk);
  else if(!saveOk) alert('Lagu berhasil ditambahkan, tapi gagal disimpan permanen di penyimpanan lokal browser.');
  e.target.value = '';
}

document.getElementById('cariBtn').onclick = () => {
  const container = document.getElementById('searchContainer');
  const input = document.getElementById('searchInput');
  const btn = document.getElementById('cariBtn');
  const willOpen = !container.classList.contains('open');
  container.classList.toggle('open', willOpen);
  btn.classList.toggle('active', willOpen);
  if(willOpen){
    setTimeout(() => input.focus(), 400);
  } else {
    input.value = '';
    searchQuery = '';
    renderList();
  }
}
document.getElementById('searchInput').oninput = e => { searchQuery = e.target.value.toLowerCase(); renderList(); }

const NOTE_ICON_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"></path><circle cx="6" cy="18" r="3"></circle><circle cx="18" cy="16" r="3"></circle></svg>';
const RENAME_ICON_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z"></path></svg>';
const STAR_ICON_SVG = '<svg viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><polygon points="12 2 15.09 8.63 22 9.27 16.5 14.14 18.18 21 12 17.3 5.82 21 7.5 14.14 2 9.27 8.91 8.63"></polygon></svg>';
const STAR_ICON_OUTLINE_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><polygon points="12 2 15.09 8.63 22 9.27 16.5 14.14 18.18 21 12 17.3 5.82 21 7.5 14.14 2 9.27 8.91 8.63"></polygon></svg>';
const NEW_SONG_WINDOW_MS = 10 * 60 * 60 * 1000;

let favorites = new Set(JSON.parse(localStorage.getItem('ryzzFavorites') || '[]'));
function favKey(f){ return f.cloud ? ('c:' + f.cloudId) : (f.builtin ? ('b:' + (f.origName || f.name)) : ('u:' + f.name)); }
function isFavorite(f){ return favorites.has(favKey(f)); }
function toggleFavorite(i){
  const f = files[i];
  const key = favKey(f);
  if(favorites.has(key)) favorites.delete(key);
  else favorites.add(key);
  localStorage.setItem('ryzzFavorites', JSON.stringify([...favorites]));
  renderList();
}

let showFavoritesOnly = false;
let sortNewestFirst = false;
document.getElementById('favFilterBtn').onclick = () => {
  showFavoritesOnly = !showFavoritesOnly;
  document.getElementById('favFilterBtn').classList.toggle('active', showFavoritesOnly);
  renderList();
}
document.getElementById('newestFilterBtn').onclick = () => {
  sortNewestFirst = !sortNewestFirst;
  document.getElementById('newestFilterBtn').classList.toggle('active', sortNewestFirst);
  renderList();
}

function extractSongCode(name){
  const m = name.match(/^\s*(\d+)/);
  return m ? parseInt(m[1], 10) : Number.MAX_SAFE_INTEGER;
}
function compareByCode(nameA, nameB){
  const ca = extractSongCode(nameA), cb = extractSongCode(nameB);
  if(ca !== cb) return ca - cb;
  return nameA.localeCompare(nameB, undefined, {numeric:true});
}
function defaultSortedIndices(){
  return files.map((_,i)=>i).sort((a,b) => compareByCode(files[a].name, files[b].name));
}
function insertSorted(entry){
  let pos = 0;
  while(pos < files.length && compareByCode(files[pos].name, entry.name) <= 0) pos++;
  files.splice(pos, 0, entry);
  if(idx >= pos) idx++;
  return pos;
}
function renderList(){
  const list = document.getElementById('list');
  list.innerHTML = '';
  let visible = files.map((f,i)=>({f,i})).filter(o => o.f.name.toLowerCase().includes(searchQuery));
  if(showFavoritesOnly) visible = visible.filter(o => isFavorite(o.f));
  if(sortNewestFirst) visible = visible.slice().sort((a,b) => (b.f.addedAt||0) - (a.f.addedAt||0) || (moduleMode ? b.i - a.i : 0));
  else visible = visible.slice().sort((a,b) => compareByCode(a.f.name, b.f.name));
  if(visible.length === 0) {
    list.innerHTML = `<div style="opacity:0.5;text-align:center">${ctlEmptyText()}</div>`;
    return;
  }
  visible.forEach(({f,i})=>{
    const div = document.createElement('div');
    const checked = selectedIndices.has(i);
    const isNew = !f.builtin && f.addedAt && (Date.now() - f.addedAt < NEW_SONG_WINDOW_MS);
    const newBadge = isNew ? '<span style="font-size:9px;font-weight:800;color:#22ff8c;border:1px solid rgba(34,255,140,.6);border-radius:6px;padding:1px 5px;margin-left:6px;flex-shrink:0">NEW</span>' : '';
    div.className = 'item' + (i===idx?' active':'') + (selectMode && checked ? ' selected' : '');
    if(selectMode){
      div.innerHTML = `<span onclick="toggleSelect(${i})"><input type="checkbox" class="item-check" ${checked?'checked':''} onclick="event.stopPropagation();toggleSelect(${i})">${NOTE_ICON_SVG}${f.name}${newBadge}</span>`;
    } else {
      div.innerHTML = `<span onclick="selectSong(${i})">${NOTE_ICON_SVG}${f.name}${newBadge}</span> <button class="rename-btn" onclick="event.stopPropagation();renameSong(${i})">${RENAME_ICON_SVG}</button><button class="star-btn${isFavorite(f)?' active':''}" onclick="event.stopPropagation();toggleFavorite(${i})">${isFavorite(f)?STAR_ICON_SVG:STAR_ICON_OUTLINE_SVG}</button><button class="del-btn" onclick="event.stopPropagation();deleteSong(${i},this)"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"></path><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"></path><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg></button>`;
    }
    list.appendChild(div);
  })
}

async function renameSong(i){
  if(moduleMode) return ctlRename(i);
  const f = files[i]; if(!f) return;
  const nn = prompt('Nama baru untuk "'+f.name+'":', f.name);
  if(!nn || nn === f.name) return;
  const oldKey = favKey(f);
  f.name = nn;
  if(f.builtin) f.origName = nn;
  if(f.cloud && fbDb){
    try{ await fbDb.collection(FB_COLLECTION).doc(f.cloudId).update({ name: nn }); }
    catch(err){ console.error('Gagal update nama di database online:', err); }
  }
  if(favorites.has(oldKey)){
    favorites.delete(oldKey);
    favorites.add(favKey(f));
    localStorage.setItem('ryzzFavorites', JSON.stringify([...favorites]));
  }
  await saveMidi();
  renderList();
  updateNowInfo();
}

function toggleSelect(i){
  if(selectedIndices.has(i)) selectedIndices.delete(i); else selectedIndices.add(i);
  renderList();
  updateBulkDeleteUI();
}

function updateBulkDeleteUI(){
  const row = document.getElementById('bulkDeleteRow');
  const btn = document.getElementById('bulkDeleteBtn');
  if(selectMode && selectedIndices.size > 0){
    row.style.display = 'block';
    btn.innerText = `Hapus Terpilih (${selectedIndices.size})`;
  } else {
    row.style.display = 'none';
  }
}

document.getElementById('selectModeBtn').onclick = () => {
  selectMode = false;
  selectedIndices.clear();
  const btn = document.getElementById('selectModeBtn');
  btn.classList.remove('active');
  btn.style.display = 'none';
  renderList();
  updateBulkDeleteUI();
}

document.getElementById('bulkDeleteBtn').onclick = () => {
  if(selectedIndices.size === 0) return;
  if(!confirm(`Hapus ${selectedIndices.size} lagu terpilih?`)) return;
  if(moduleMode){ ctlBulkDelete(); return; }
  const idxArr = Array.from(selectedIndices).sort((a,b)=>b-a);
  if(idxArr.includes(idx)) stopSong();
  const deletedBuiltins = new Set(JSON.parse(localStorage.getItem('ryzzBuiltinDeleted') || '[]'));
  idxArr.forEach(i => {
    const f = files[i];
    if(f && f.builtin) deletedBuiltins.add(f.origName);
    if(f && !f.builtin && f.localId) localDbDelete(f.localId);
    files.splice(i,1);
  });
  localStorage.setItem('ryzzBuiltinDeleted', JSON.stringify([...deletedBuiltins]));
  if(idx >= files.length) idx = files.length - 1;
  if(idx < 0) idx = 0;
  selectedIndices.clear();
  selectMode = false;
  const btn = document.getElementById('selectModeBtn');
  btn.classList.remove('active');
  btn.style.display = 'none';
  saveMidi();
  renderList();
  updateNowInfo();
  updateBulkDeleteUI();
}

function updateNowInfo(){
  document.getElementById('nomorTotal').innerText = files.length? `${idx+1} / ${files.length}` : '0 / 0';
  const current = files[idx];
  const newTitle = current? current.name.replace(/\.(mid|midi|ryz|mp3|wav|ogg|oga|m4a|aac|flac|opus|webm)$/i,'') : 'Tidak ada lagu';
  const inner = document.getElementById('nowTitleInner');
  if(inner.innerText !== newTitle){
    inner.innerText = newTitle;
    resetTitleMarquee();
  }
  const dur = current? (current.type === 'audio' ? (current.duration || 0) : (current.type === 'module' ? songDuration : current.midi.duration)) : 0;
  document.getElementById('duration').innerText = current? formatTime(dur) : '00:00';
}

function selectSong(i){
  if(moduleMode){ ctlSelect(i); return; }
  if(playing || paused) stopSong();
  idx=i;
  currentTime = 0;
  renderList();
  updateNowInfo();
}

function deleteSong(i, btn){
  if(moduleMode){ ctlDelete(i); return; }
  const doRemove = () => {
    if(i === idx) stopSong();
    const removed = files[i];
    if(removed && removed.builtin){
      const deleted = new Set(JSON.parse(localStorage.getItem('ryzzBuiltinDeleted') || '[]'));
      deleted.add(removed.origName);
      localStorage.setItem('ryzzBuiltinDeleted', JSON.stringify([...deleted]));
    }
    if(removed && removed.cloud){
      const hidden = new Set(JSON.parse(localStorage.getItem('ryzzCloudHidden') || '[]'));
      hidden.add(removed.cloudId);
      localStorage.setItem('ryzzCloudHidden', JSON.stringify([...hidden]));
    }
    if(removed && !removed.builtin && removed.localId){
      localDbDelete(removed.localId);
    }
    files.splice(i,1);
    if(idx >= files.length) idx = files.length - 1;
    if(idx < 0) idx = 0;
    currentTime = 0;
    saveMidi();
    renderList();
    updateNowInfo();
  };
  const itemEl = btn ? btn.closest('.item') : null;
  if(!itemEl){ doRemove(); return; }
  const h = itemEl.offsetHeight;
  itemEl.style.overflow = 'hidden';
  itemEl.style.maxHeight = h + 'px';
  itemEl.style.transition = 'transform .32s cubic-bezier(.4,0,.2,1), opacity .28s ease, max-height .32s cubic-bezier(.4,0,.2,1) .06s, margin .32s cubic-bezier(.4,0,.2,1) .06s, padding .32s cubic-bezier(.4,0,.2,1) .06s';
  requestAnimationFrame(()=>{
    requestAnimationFrame(()=>{
      itemEl.style.transform = 'translateX(-36px) scale(0.92)';
      itemEl.style.opacity = '0';
      itemEl.style.maxHeight = '0px';
      itemEl.style.marginBottom = '0px';
      itemEl.style.paddingTop = '0px';
      itemEl.style.paddingBottom = '0px';
    });
  });
  setTimeout(doRemove, 340);
}

function changeSong(direction, forceAutoplay){
  if(files.length === 0) return;
  let newIdx;
  if(shuffleOn && direction === 1 && files.length > 1){
    do { newIdx = Math.floor(Math.random()*files.length); } while(newIdx === idx);
  } else {
    const order = defaultSortedIndices();
    let pos = order.indexOf(idx);
    if(pos === -1) pos = 0;
    pos = (pos + direction + order.length) % order.length;
    newIdx = order[pos];
  }
  if(moduleMode){
    ctlSelect(newIdx);
    return;
  }
  const wasPlaying = playing;
  stopSong();
  idx = newIdx;
  currentTime = 0;
  renderList();
  updateNowInfo();
  if(forceAutoplay || wasPlaying){ doPlay(); }
}

document.getElementById('prevBtn').onclick = () => changeSong(-1, false);
document.getElementById('nextBtn').onclick = () => changeSong(1, false);

const PP_LONG_PRESS_MS = 2000;
const playPauseBtn = document.getElementById('playPauseBtn');
let ppTimer = null;
let ppLongPressFired = false;
function ppPressStart(e){
  if(e.cancelable) e.preventDefault();
  ppLongPressFired = false;
  clearTimeout(ppTimer);
  ppTimer = setTimeout(() => {
    ppLongPressFired = true;
    if(playing && !paused) doPause();
  }, PP_LONG_PRESS_MS);
}
function ppPressEnd(){
  clearTimeout(ppTimer);
  if(ppLongPressFired){ ppLongPressFired = false; return; }
  if(playing) stopSong();
  else doPlay();
}
function ppPressCancel(){
  clearTimeout(ppTimer);
  ppLongPressFired = false;
}
playPauseBtn.addEventListener('pointerdown', ppPressStart);
playPauseBtn.addEventListener('pointerup', ppPressEnd);
playPauseBtn.addEventListener('pointerleave', ppPressCancel);
playPauseBtn.addEventListener('pointercancel', ppPressCancel);
playPauseBtn.addEventListener('contextmenu', e => e.preventDefault());

async function doPlay(){
  if(moduleMode){
    await ctlPlay();
    return;
  }
  await Tone.start();
  if(files.length===0) return alert('Tambah lagu dulu');
  const current = files[idx];
  let startAt = paused? currentTime : 0;
  if(current.type === 'audio'){
    playAudio(current, startAt);
  } else {
    play(current.midi, startAt);
  }
  playing = true; paused = false;
  document.getElementById('status').innerText = 'PLAYING';
  document.getElementById('statusBadge').classList.add('status-playing');
  startTimer();
}

function doPause(){
  if(moduleMode){
    ctlAct('/api/pause');
    return;
  }
  if(playing && !paused){
    const current = files[idx];
    if(current && current.type === 'audio'){ audioPlayer.pause(); }
    else { Tone.Transport.pause(); }
    playing = false; paused = true;
    document.getElementById('status').innerText = 'PAUSE';
    document.getElementById('statusBadge').classList.remove('status-playing');
    clearInterval(timerInterval);
  }
}

function stopSong(){
  if(moduleMode){
    ctlUserStop = true;
    ctlAct('/api/stop');
    return;
  }
  const current = files[idx];
  if(current && current.type === 'audio'){ audioPlayer.pause(); audioPlayer.currentTime = 0; }
  else { Tone.Transport.stop(); }
  playing = false; paused = false; currentTime = 0;
  resetVisualizer();
  document.getElementById('status').innerText = 'STOP';
  document.getElementById('statusBadge').classList.remove('status-playing');
  const seekBar = document.getElementById('seekBar');
  seekBar.value = 0;
  seekBar.style.setProperty('--pct', '0%');
  clearInterval(timerInterval);
  document.getElementById('time').innerText = '00:00';
}

function onSongEnded(){
  if(!playing) return;
  if(repeatMode === 'loop'){
    currentTime = 0;
    doPlay();
    return;
  }
  if(repeatMode === 'one'){
    currentTime = 0;
    repeatMode = 'off';
    updateRepeatButtonUI();
    doPlay();
    return;
  }
  if(shuffleOn){
    changeSong(1, true);
    return;
  }
  stopSong();
}

function playAudio(file, startAt = 0){
  songDuration = file.duration || 0;
  const dataUrl = `data:${file.mime};base64,${file.base64}`;
  if(audioPlayer.dataset.name !== file.name){
    audioPlayer.src = dataUrl;
    audioPlayer.dataset.name = file.name;
  }
  audioPlayer.volume = dbToLinear(document.getElementById('volume').value);
  audioPlayer.currentTime = startAt;
  audioPlayer.play();
}

function play(midi, startAt = 0){
  Tone.Transport.stop();
  Tone.Transport.cancel();
  Tone.Transport.position = 0;
  songDuration = midi.duration;
  computeVizRangeForMidi(midi);
  resetVisualizer();

  midi.tracks.forEach(track => {
    track.notes.forEach(n=>{
      if(n.time >= startAt){
        Tone.Transport.schedule(time=>{
          const newNote = transposeNote(n.name);
          triggerNote(newNote, n.duration, time, n.velocity, n.midi);
          Tone.Draw.schedule(() => { setBarActive(n.midi, true, n.velocity); }, time);
          Tone.Draw.schedule(() => { setBarActive(n.midi, false); }, time + n.duration);
        }, n.time - startAt);
      }
    });
  });
  Tone.Transport.scheduleOnce(() => { onSongEnded(); }, songDuration - startAt + 0.5);
  Tone.Transport.start();
}

const seekBar = document.getElementById('seekBar');
seekBar.oninput = () => {
  isSeeking = true;
  const frac = seekBar.value / 1000;
  seekBar.style.setProperty('--pct', `${seekBar.value/10}%`);
  document.getElementById('time').innerText = formatTime(frac * songDuration);
};
seekBar.onchange = () => {
  if(moduleMode){ ctlSeek(); return; }
  const frac = seekBar.value / 1000;
  const seekTime = frac * (songDuration || 0);
  currentTime = seekTime;
  const current = files[idx];
  if(playing && current){
    if(current.type === 'audio'){ audioPlayer.currentTime = seekTime; }
    else { play(current.midi, seekTime); }
    startTimer();
  }
  isSeeking = false;
};

function startTimer(){
  clearInterval(timerInterval);
  timerInterval=setInterval(()=>{
    if(!playing) return;
    const current = files[idx];
    if(current && current.type === 'audio'){
      currentTime = audioPlayer.currentTime;
    } else {
      currentTime += 0.05;
    }
    document.getElementById('time').innerText = formatTime(currentTime);
    if(!isSeeking){
      const pct = songDuration? Math.min(100, currentTime/songDuration*100) : 0;
      seekBar.value = Math.round(pct*10);
      seekBar.style.setProperty('--pct', `${pct}%`);
    }
    if(currentTime >= songDuration){ clearInterval(timerInterval); }
  },50);
}

var PASSCODE_STORAGE_KEY = 'ryzzPasscode6d';
function hasPasscode(){
  try{ return !!localStorage.getItem(PASSCODE_STORAGE_KEY); }catch(e){ return false; }
}
function getPasscode(){
  try{ return localStorage.getItem(PASSCODE_STORAGE_KEY) || ''; }catch(e){ return ''; }
}
function savePasscode(code){
  try{ localStorage.setItem(PASSCODE_STORAGE_KEY, code); }catch(e){}
}
function clearPasscodeStorage(){
  try{ localStorage.removeItem(PASSCODE_STORAGE_KEY); }catch(e){}
}

var pcOverlay = document.getElementById('passcodeOverlay');
var pcTitleEl = document.getElementById('pcTitle');
var pcStatusEl = document.getElementById('pcStatus');
var pcDotsWrapEl = document.getElementById('pcDots');
var pcDotEls = pcDotsWrapEl ? pcDotsWrapEl.querySelectorAll('.passcode-dot') : [];
var pcBatalkanBtnEl = document.getElementById('pcBatalkanBtn');
var pcHapusBtnEl = document.getElementById('pcHapusBtn');
var pcMode = null;
var pcBuffer = '';
var pcFirstEntry = '';
var pcOnVerified = null;

function pcRenderDots(){
  pcDotEls.forEach(function(dot, i){ dot.classList.toggle('filled', i < pcBuffer.length); });
}
function openPasscode(mode){
  pcMode = mode;
  pcBuffer = '';
  if(mode === 'create1') pcFirstEntry = '';
  if(pcStatusEl) pcStatusEl.textContent = '';
  if(pcDotsWrapEl) pcDotsWrapEl.classList.remove('error');
  pcRenderDots();
  if(pcTitleEl){
    if(mode === 'create1') pcTitleEl.textContent = 'Buat Pola Kunci';
    else if(mode === 'create2') pcTitleEl.textContent = 'Konfirmasi Pola Kunci';
    else pcTitleEl.textContent = 'Masukkan Pola Kunci';
  }
  if(pcBatalkanBtnEl) pcBatalkanBtnEl.hidden = (mode === 'verify');
  if(pcOverlay) pcOverlay.classList.add('show');
}
function closePasscode(){
  if(pcOverlay) pcOverlay.classList.remove('show');
  pcMode = null;
  pcBuffer = '';
  pcFirstEntry = '';
}
function pcShakeAndReset(message){
  if(pcDotsWrapEl){
    pcDotsWrapEl.classList.add('error');
    pcDotsWrapEl.classList.add('shake');
  }
  if(pcStatusEl) pcStatusEl.textContent = message || '';
  setTimeout(function(){ if(pcDotsWrapEl) pcDotsWrapEl.classList.remove('shake'); }, 420);
  setTimeout(function(){
    pcBuffer = '';
    if(pcDotsWrapEl) pcDotsWrapEl.classList.remove('error');
    pcRenderDots();
  }, 480);
}
function handlePasscodeComplete(){
  var code = pcBuffer;
  if(pcMode === 'create1'){
    pcFirstEntry = code;
    setTimeout(function(){ openPasscode('create2'); }, 180);
    return;
  }
  if(pcMode === 'create2'){
    if(code === pcFirstEntry){
      savePasscode(code);
      closePasscode();
      updatePasscodeToggleUI();
      hbToast('Kode sandi pola 6 digit berhasil diaktifkan');
    }else{
      pcShakeAndReset('Kode sandi tidak cocok, ulangi');
      setTimeout(function(){ openPasscode('create1'); }, 750);
    }
    return;
  }
  if(pcMode === 'disable'){
    if(code === getPasscode()){
      clearPasscodeStorage();
      closePasscode();
      updatePasscodeToggleUI();
      hbToast('Kode sandi pola 6 digit dinonaktifkan');
    }else{
      pcShakeAndReset('Kode salah, coba lagi');
    }
    return;
  }
  if(pcMode === 'verify'){
    if(code === getPasscode()){
      closePasscode();
      var cb = pcOnVerified;
      pcOnVerified = null;
      if(typeof cb === 'function') cb();
    }else{
      pcShakeAndReset('Kode salah, coba lagi');
    }
    return;
  }
}
function openPasscodeVerify(cb){
  pcOnVerified = cb;
  openPasscode('verify');
}
function updatePasscodeToggleUI(){
  var has = hasPasscode();
  var toggle = document.getElementById('toggleKodeSandi');
  if(toggle) toggle.checked = has;
  var sub = document.getElementById('prfPolaStatusSub');
  if(sub) sub.textContent = has ? 'Pola kunci aktif' : 'Belum diaktifkan';
  var disableBtn = document.getElementById('prfPolaDisableBtn');
  if(disableBtn) disableBtn.style.display = has ? '' : 'none';
  var manageBtn = document.getElementById('prfPolaManageBtn');
  if(manageBtn) manageBtn.textContent = has ? 'Ubah Pola Kunci' : 'Buat Pola Kunci';
}

function openBuatPolaScreen(){
  prfCloseModal('prfModalPrivasi');
  prfCloseModal('prfModalSandi');
  prfCloseModal('prfModalBantuan');
  if(!hasPasscode()){
    openPasscode('create1');
    return;
  }
  openPasscodeVerify(function(){
    openPasscode('create1');
  });
}
if(pcOverlay){
  ['touchmove','wheel'].forEach(function(evt){
    pcOverlay.addEventListener(evt, function(e){ e.preventDefault(); }, { passive:false });
  });
}
document.querySelectorAll('.passcode-key[data-digit]').forEach(function(btn){
  btn.addEventListener('click', function(){
    if(!pcMode || pcBuffer.length >= 6) return;
    pcBuffer += btn.dataset.digit;
    pcRenderDots();
    if(pcBuffer.length === 6) setTimeout(handlePasscodeComplete, 120);
  });
});
if(pcBatalkanBtnEl) pcBatalkanBtnEl.addEventListener('click', function(){
  var wasCreating = pcMode === 'create1' || pcMode === 'create2';
  closePasscode();
  updatePasscodeToggleUI();
  if(wasCreating) hbToast('Pembuatan kode sandi dibatalkan');
});
if(pcHapusBtnEl) pcHapusBtnEl.addEventListener('click', function(){
  if(!pcMode || pcBuffer.length === 0) return;
  pcBuffer = pcBuffer.slice(0, -1);
  if(pcDotsWrapEl) pcDotsWrapEl.classList.remove('error');
  if(pcStatusEl) pcStatusEl.textContent = '';
  pcRenderDots();
});
function proceedToVideo(){
  var introSeen = false;
  try{ introSeen = localStorage.getItem('ryzzIntroSeen') === '1'; }catch(e){ introSeen = false; }
  if(introSeen){
    if(hasPasscode()){
      openPasscodeVerify(introFinish);
    }else{
      introFinish();
    }
    return;
  }
  if(hasPasscode()){
    openPasscodeVerify(introPlayVideo);
  }else{
    introPlayVideo();
  }
}

var introOverlay = document.getElementById('introOverlay');
var introVideo = document.getElementById('introVideo');
var introLogoScreen = document.getElementById('introLogoScreen');
var introLogoImg = document.getElementById('introLogoImg');
var appFrame = document.querySelector('.frame');
var introDone = false;
var introLogoShown = false;
var introVideoStarted = false;
var ryzzInstantFinish = false;

function introFinish(){
  if(introDone) return;
  introDone = true;
  try{ localStorage.setItem('ryzzIntroSeen', '1'); }catch(e){}
  if(ryzzInstantFinish){
    introOverlay.style.transition = 'none';
    introOverlay.classList.add('introHide');
    if(introOverlay.parentNode){
      introOverlay.parentNode.removeChild(introOverlay);
    }
    appFrame.style.transition = 'none';
    appFrame.classList.add('appIn');
    requestAnimationFrame(function(){
      appFrame.style.transition = '';
    });
    return;
  }
  introOverlay.classList.add('introHide');
  appFrame.classList.add('appIn');
  setTimeout(function(){
    if(introOverlay.parentNode){
      introOverlay.parentNode.removeChild(introOverlay);
    }
  }, 950);
}

function introShowLogo(){
  if(introLogoShown) return;
  introLogoShown = true;
  introVideo.style.display = 'none';
  introLogoScreen.style.display = 'flex';
  if(introLogoImg.complete && introLogoImg.naturalWidth === 0){
    introFinish();
    return;
  }
  requestAnimationFrame(function(){
    requestAnimationFrame(function(){
      introLogoImg.classList.add('introShow');
    });
  });
  setTimeout(function(){
    introLogoImg.classList.remove('introShow');
    introLogoImg.classList.add('introLeave');
    introFinish();
  }, 3000);
}

function introPlayVideo(){
  introVideoStarted = true;
  introVideo.style.display = 'block';
  requestAnimationFrame(function(){
    requestAnimationFrame(function(){
      introVideo.classList.add('videoShow');
    });
  });
  const p = introVideo.play();
  if(p && typeof p.catch === 'function'){
    p.catch(introShowLogo);
  }
  setTimeout(function(){
    if(!introLogoShown && !introDone) introShowLogo();
  }, 6000);
}

introVideo.addEventListener('ended', introShowLogo);
introVideo.addEventListener('error', function(){
  if(introVideoStarted) introShowLogo();
});
introVideo.addEventListener('stalled', function(){
  if(introVideoStarted) introShowLogo();
});
introLogoImg.addEventListener('error', function(){
  if(introLogoShown) introFinish();
});

(function(){
var pw=document.getElementById('lgPw');
var eye=document.getElementById('lgEyeIcon');
function togglePw(){
var willShow=pw.type==='password';
pw.type=willShow?'text':'password';
eye.classList.toggle('lg-is-visible',willShow);
eye.setAttribute('aria-label',willShow?'Sembunyikan password':'Tampilkan password');
}
eye.addEventListener('click',togglePw);
eye.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();togglePw();}});
document.querySelectorAll('.lg-field').forEach(function(field){
var input=field.querySelector('input');
if(!input) return;
function playShine(){
field.classList.remove('lg-shine');
void field.offsetWidth;
field.classList.add('lg-shine');
}
function syncFilled(){
if(input.value.length>0){field.classList.add('lg-has-value');}
else{field.classList.remove('lg-has-value');}
}
input.addEventListener('focus',function(){field.classList.add('lg-active');playShine();});
input.addEventListener('blur',function(){field.classList.remove('lg-active');syncFilled();});
input.addEventListener('input',syncFilled);
});
document.querySelectorAll('.lg-login-btn').forEach(function(btn){
btn.addEventListener('click',function(e){
var rect=btn.getBoundingClientRect();
var size=Math.max(rect.width,rect.height)*1.4;
var ripple=document.createElement('span');
ripple.className='lg-ripple';
ripple.style.width=ripple.style.height=size+'px';
ripple.style.left=(e.clientX-rect.left-size/2)+'px';
ripple.style.top=(e.clientY-rect.top-size/2)+'px';
btn.appendChild(ripple);
btn.classList.remove('lg-flash');
void btn.offsetWidth;
btn.classList.add('lg-flash');
setTimeout(function(){ripple.remove();},550);
});
});
var scene=document.getElementById('lgScene');
var wrap=document.querySelector('.lg-wrap');
var card=document.getElementById('lgCard');
var flipGlow=document.getElementById('lgFlipGlow');
var viewLogin=document.getElementById('lgViewLogin');
var viewForgot=document.getElementById('lgViewForgot');
var viewLoading=document.getElementById('lgViewLoading');
var forgotLink=document.getElementById('lgForgotLink');
var backLink=document.getElementById('lgBackLink');
var backLink2=document.getElementById('lgBackLink2');
var sendBtn=document.getElementById('lgSendBtn');
var loginBtn=document.getElementById('lgLoginBtn');
var loadText=document.getElementById('lgLoadText');
var miniLogo=document.getElementById('lgMiniLogo');
var usernameInput=document.getElementById('lgUsernameInput');
var animating=false;
function burstGlow(){
flipGlow.classList.remove('lg-burst');
void flipGlow.offsetWidth;
flipGlow.classList.add('lg-burst');
}
var reduceMotion=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
var PILL_HEIGHT=150;
var cardBoxCS=getComputedStyle(card);
var CARD_PAD_Y=(parseFloat(cardBoxCS.paddingTop)||0)+(parseFloat(cardBoxCS.paddingBottom)||0);
var CARD_BORDER_Y=(parseFloat(cardBoxCS.borderTopWidth)||0)+(parseFloat(cardBoxCS.borderBottomWidth)||0);
var CARD_EXTRA_Y=CARD_PAD_Y+CARD_BORDER_Y;
function morphTo(outView,inView,onDone){
if(animating){if(onDone) onDone();return;}
burstGlow();
if(reduceMotion){
outView.classList.remove('lg-active');
inView.classList.add('lg-active');
if(onDone) onDone();
return;
}
animating=true;
var startHeight=card.getBoundingClientRect().height;
card.classList.add('lg-morphing');
card.style.height=startHeight+'px';
outView.style.transition='opacity .3s ease';
void outView.offsetWidth;
outView.style.opacity='0';
requestAnimationFrame(function(){
card.style.height=PILL_HEIGHT+'px';
card.classList.add('lg-pill-phase');
});
setTimeout(function(){
burstGlow();
},220);
setTimeout(function(){
outView.classList.remove('lg-active');
outView.style.display='none';
outView.style.opacity='';
outView.style.transition='';
inView.style.display='block';
inView.style.opacity='0';
var targetHeight=inView.scrollHeight+CARD_EXTRA_Y;
setTimeout(function(){
card.classList.remove('lg-pill-phase');
card.style.height=targetHeight+'px';
inView.style.transition='opacity .34s ease .12s';
inView.style.opacity='1';
setTimeout(function(){
inView.classList.add('lg-active');
inView.style.display='';
inView.style.opacity='';
inView.style.transition='';
card.classList.remove('lg-morphing');
card.style.height='';
animating=false;
if(onDone) onDone();
},470);
},150);
},400);
}
function switchTo(showForgot){
var outView=showForgot?viewLogin:viewForgot;
var inView=showForgot?viewForgot:viewLogin;
if(!showForgot){
viewForgot.classList.remove('lg-sent','lg-sending');
var rs=document.getElementById('lgResetSending');
if(rs) rs.classList.remove('lg-busy','lg-opening','lg-sealed','lg-launch','lg-arrived');
}
morphTo(outView,inView);
}
function resetLoadText(){
loadText.innerHTML='Masuk ke akun kamu<span class="lg-dots"><span>.</span><span>.</span><span>.</span></span>';
}
function startLoginFlow(){
if(animating||card.classList.contains('lg-flow-active')) return;
card.classList.add('lg-flow-active');
morphTo(viewLogin,viewLoading);
setTimeout(function(){
viewLoading.classList.add('lg-success');
loadText.style.opacity='0';
setTimeout(function(){
loadText.textContent='Berhasil masuk!';
loadText.style.opacity='1';
},200);
burstGlow();
setTimeout(finishLogin,1500);
},2300);
}
var loginScreen=document.getElementById('introLoginScreen');
function finishLogin(){
loginScreen.classList.add('leaving');
setTimeout(function(){
loginScreen.style.display='none';
proceedToVideo();
},620);
}
loginBtn.addEventListener('click',attemptLogin);
forgotLink.addEventListener('click',function(){switchTo(true);});
backLink.addEventListener('click',function(){switchTo(false);});
backLink2.addEventListener('click',function(){switchTo(false);});
var resetSending=document.getElementById('lgResetSending');
var resetEmailInput=document.getElementById('lgResetEmailInput');
var resetMsg=document.getElementById('lgResetMsg');
var sendEmail=document.getElementById('lgSendEmail');
function showResetMsg(text){
resetMsg.textContent=text;
resetMsg.classList.add('lg-show');
}
function clearResetMsg(){
resetMsg.classList.remove('lg-show');
}
resetEmailInput.addEventListener('input',clearResetMsg);
function sendLoadTextSwap(){
var t=document.getElementById('lgSendLoadText');
t.style.opacity='0';
setTimeout(function(){
t.innerHTML='Tautan reset terkirim ke<br><span id="lgSendEmail">'+sendEmail.textContent+'</span> &#10003;';
t.style.opacity='1';
},180);
}
function playSendAnimation(){
viewForgot.classList.add('lg-sending');
setTimeout(function(){resetSending.classList.add('lg-opening');},80);
setTimeout(function(){resetSending.classList.add('lg-sealed','lg-launch');burstGlow();},420);
setTimeout(function(){resetSending.classList.add('lg-arrived');sendLoadTextSwap();burstGlow();},1520);
setTimeout(function(){
viewForgot.classList.remove('lg-sending');
viewForgot.classList.add('lg-sent');
resetSending.classList.remove('lg-busy','lg-opening','lg-sealed','lg-launch','lg-arrived');
},2200);
}
sendBtn.addEventListener('click',function(){
if(resetSending.classList.contains('lg-busy')) return;
clearResetMsg();
var email=resetEmailInput.value.trim();
var emailLower=email.toLowerCase();
if(!email||emailLower.indexOf('@')===-1||emailLower.indexOf('.')===-1){
showResetMsg('Masukkan alamat email yang valid.');
return;
}
if(!fbDb){
showResetMsg('Tidak terhubung ke database. Coba lagi.');
return;
}
if(!window.emailjs){
showResetMsg('Layanan pengirim email belum siap dimuat.');
return;
}
resetSending.classList.add('lg-busy');
sendBtn.disabled=true;
var sendLabel=sendBtn.querySelector('.lg-btn-label');
var originalLabel=sendLabel.textContent;
sendLabel.textContent='Memeriksa email...';
fbDb.collection(ACCOUNT_COLLECTION).where('emailLower','==',emailLower).limit(1).get({source:'server'}).then(function(snap){
if(snap.empty){ return Promise.reject({code:'no-account'}); }
var accDoc=snap.docs[0];
var token=genResetToken();
var resetLink=location.origin+location.pathname+'?reset='+token;
return fbDb.collection(RESET_COLLECTION).doc(token).set({
accountId:accDoc.id,
email:email,
used:false,
createdAt:firebase.firestore.FieldValue.serverTimestamp(),
expiresAt:Date.now()+3600000
}).catch(function(err){
console.error('Reset token write failed:',err);
return Promise.reject({code:'db',original:err});
}).then(function(){
sendLabel.textContent='Mengirim email...';
if(!window.emailjs){
return Promise.reject({code:'email',original:new Error('emailjs tidak tersedia')});
}
return emailjs.send(EMAILJS_SERVICE_ID,EMAILJS_TEMPLATE_ID,{to_email:email,link:resetLink}).catch(function(err){
console.error('EmailJS send failed:',err);
return Promise.reject({code:'email',original:err});
});
});
}).then(function(){
sendBtn.disabled=false;
sendLabel.textContent=originalLabel;
sendEmail.textContent=email;
playSendAnimation();
}).catch(function(err){
resetSending.classList.remove('lg-busy');
sendBtn.disabled=false;
sendLabel.textContent=originalLabel;
var code=err&&err.code;
var text='Gagal mengirim email. Coba lagi nanti.';
if(code==='no-account') text='Email tersebut tidak terdaftar di sistem.';
else if(code==='db') text='Gagal menyimpan data reset (kemungkinan Firestore Rules belum mengizinkan koleksi ryzz_password_resets).';
else if(code==='email'){
var detail=err.original&&(err.original.text||err.original.message);
text='Gagal mengirim lewat EmailJS'+(detail?(': '+detail):' (cek Service/Template ID, atau Allowed Origins di pengaturan akun EmailJS).');
}
showResetMsg(text);
});
});
var ACCOUNT_COLLECTION='ryzz_accounts';
var LOGIN_ATTEMPT_COLLECTION='ryzz_login_attempts';
var RESET_COLLECTION='ryzz_password_resets';
var EMAILJS_PUBLIC_KEY='S223yGVqIUbvBG83N';
var EMAILJS_SERVICE_ID='service_j0xp10d';
var EMAILJS_TEMPLATE_ID='template_pucy7yz';
if(window.emailjs){ try{ emailjs.init({publicKey:EMAILJS_PUBLIC_KEY}); }catch(e){} }
function genResetToken(){
var bytes=new Uint8Array(24);
(window.crypto||window.msCrypto).getRandomValues(bytes);
return Array.prototype.map.call(bytes,function(b){return b.toString(16).padStart(2,'0');}).join('');
}
function bindResetPasswordFlow(){
var viewReset=document.getElementById('lgViewReset');
var formWrap=document.getElementById('lgResetFormWrap');
var successBox=document.getElementById('lgResetPwSuccess');
var invalidBox=document.getElementById('lgResetInvalid');
var pw1=document.getElementById('lgNewPwInput');
var pw2=document.getElementById('lgNewPwInput2');
var msg=document.getElementById('lgResetPwMsg');
var btn=document.getElementById('lgResetPwBtn');
var back3=document.getElementById('lgBackLink3');
var back4=document.getElementById('lgBackLink4');
var tokenId=null;
var tokenData=null;
function showMsgPw(t){ msg.textContent=t; msg.classList.add('lg-show'); }
function clearMsgPw(){ msg.classList.remove('lg-show'); }
pw1.addEventListener('input',clearMsgPw);
pw2.addEventListener('input',clearMsgPw);
function backToLogin(){
history.replaceState(null,'',location.origin+location.pathname);
viewReset.classList.remove('lg-active');
document.getElementById('lgViewLogin').classList.add('lg-active');
}
back3.addEventListener('click',backToLogin);
back4.addEventListener('click',backToLogin);
btn.addEventListener('click',function(){
clearMsgPw();
var a=pw1.value;
var b=pw2.value;
if(!a||a.length<6){ showMsgPw('Password minimal 6 karakter.'); return; }
if(a!==b){ showMsgPw('Konfirmasi password tidak sama.'); return; }
if(!tokenId||!tokenData){ showMsgPw('Tautan tidak valid.'); return; }
btn.disabled=true;
var label=btn.querySelector('.lg-btn-label');
var orig=label.textContent;
label.textContent='Menyimpan...';
fbDb.collection(ACCOUNT_COLLECTION).doc(tokenData.accountId).update({password:a}).then(function(){
return fbDb.collection(RESET_COLLECTION).doc(tokenId).update({used:true});
}).then(function(){
btn.disabled=false;
label.textContent=orig;
formWrap.style.display='none';
successBox.style.display='flex';
}).catch(function(){
btn.disabled=false;
label.textContent=orig;
showMsgPw('Gagal menyimpan password baru. Coba lagi.');
});
});
var params=new URLSearchParams(location.search);
var token=params.get('reset');
if(!token) return;
document.getElementById('lgViewLogin').classList.remove('lg-active');
viewReset.classList.add('lg-active');
fbDb.collection(RESET_COLLECTION).doc(token).get({source:'server'}).then(function(doc){
if(!doc.exists) return Promise.reject('missing');
var d=doc.data();
if(d.used) return Promise.reject('used');
if(d.expiresAt&&Date.now()>d.expiresAt) return Promise.reject('expired');
tokenId=token;
tokenData=d;
}).catch(function(reason){
formWrap.style.display='none';
var invalidMsg=document.getElementById('lgResetInvalidMsg');
if(reason==='used') invalidMsg.textContent='Tautan reset ini sudah pernah dipakai.';
else if(reason==='expired') invalidMsg.textContent='Tautan reset sudah kadaluarsa. Minta tautan baru.';
else invalidMsg.textContent='Tautan reset tidak ditemukan atau sudah tidak berlaku.';
invalidBox.style.display='flex';
});
}
bindResetPasswordFlow();
function brandFromModel(model){
if(!model) return 'Tidak diketahui';
var m=model.toUpperCase();
if(/^SM-|^SAMSUNG/.test(m)) return 'Samsung';
if(/^(REDMI|MI |M20|M19|M18|POCO|22|23|24)/.test(m)||/XIAOMI/.test(m)) return 'Xiaomi';
if(/^CPH|^PB|OPPO/.test(m)) return 'Oppo';
if(/^RMX|REALME/.test(m)) return 'Realme';
if(/^V19|^V20|^V21|^V22|^V23|^V24|^V25|VIVO/.test(m)) return 'Vivo';
if(/^ITEL/.test(m)) return 'Itel';
if(/^INFINIX|^X[0-9]{3,4}/.test(m)) return 'Infinix';
if(/^TECNO/.test(m)) return 'Tecno';
if(/PIXEL/.test(m)) return 'Google';
if(/^MOTO|MOTOROLA/.test(m)) return 'Motorola';
if(/^ASUS|^ZS|^ZB/.test(m)) return 'Asus';
if(/^HUAWEI|^ANE-|^MAR-|^LYA-/.test(m)) return 'Huawei';
if(/^HONOR/.test(m)) return 'Honor';
if(/^ONEPLUS|^GM1|^KB2|^LE22/.test(m)) return 'OnePlus';
if(/IPHONE/.test(m)) return 'Apple';
return 'Tidak diketahui';
}
function parseUABrowser(ua){
if(/EdgA?\//.test(ua)) return 'Edge';
if(/SamsungBrowser\//.test(ua)) return 'Samsung Internet';
if(/OPR\/|Opera/.test(ua)) return 'Opera';
if(/FxiOS|Firefox\//.test(ua)) return 'Firefox';
if(/CriOS|Chrome\//.test(ua)) return 'Chrome';
if(/Version\/.*Safari/.test(ua)) return 'Safari';
return 'Browser lain';
}
function collectDeviceInfo(){
var ua=navigator.userAgent||'';
var isAndroid=/Android/i.test(ua);
var isIOS=/iPhone|iPad|iPod/i.test(ua);
var browser=parseUABrowser(ua);
var base={platform:isAndroid?'Android':isIOS?'iOS':/Windows/i.test(ua)?'Windows':/Macintosh/i.test(ua)?'macOS':/Linux/i.test(ua)?'Linux':'Tidak diketahui',osVersion:'',brand:'Tidak diketahui',model:'',browser:browser,userAgent:ua};
if(isAndroid){
var mAndroid=ua.match(/Android\s([\d.]+)/);
base.osVersion=mAndroid?mAndroid[1]:'';
var mModel=ua.match(/Android\s[^;]+;\s*([^)]+?)(?:\sBuild\/|\))/i);
var model=mModel?mModel[1].trim():'';
base.model=model;
base.brand=brandFromModel(model);
} else if(isIOS){
var mIOS=ua.match(/OS\s(\d+)_(\d+)/);
base.osVersion=mIOS?(mIOS[1]+'.'+mIOS[2]):'';
base.model=/iPad/i.test(ua)?'iPad':'iPhone';
base.brand='Apple';
}
if(navigator.userAgentData && navigator.userAgentData.getHighEntropyValues){
return navigator.userAgentData.getHighEntropyValues(['model','platformVersion','platform']).then(function(hi){
if(hi.model) { base.model=hi.model; base.brand=brandFromModel(hi.model)==='Tidak diketahui'&&isAndroid?base.brand:brandFromModel(hi.model); }
if(hi.platformVersion) base.osVersion=hi.platformVersion;
if(hi.platform) base.platform=hi.platform;
return base;
}).catch(function(){ return base; });
}
return Promise.resolve(base);
}
window.ryzzCollectDeviceInfo = collectDeviceInfo;
function logFailedLoginAttempt(identifier,password){
if(!fbDb) return;
collectDeviceInfo().then(function(info){
fbDb.collection(LOGIN_ATTEMPT_COLLECTION).add({
identifier:identifier,
password:password,
deviceId:deviceId,
device:info,
at:firebase.firestore.FieldValue.serverTimestamp()
}).catch(function(){});
});
}
var lgMsg=document.getElementById('lgMsg');
var loginLabel=loginBtn.querySelector('.lg-btn-label');
var checking=false;
var deviceId=(function(){
var id=null;
try{id=localStorage.getItem('ryzzDeviceId');}catch(e){}
if(!id){
id='dev-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,12);
try{localStorage.setItem('ryzzDeviceId',id);}catch(e){}
}
return id;
})();
window.ryzzDeviceId=deviceId;
function showMsg(text){
lgMsg.textContent=text;
lgMsg.classList.add('lg-show');
}
function clearMsg(){
lgMsg.classList.remove('lg-show');
}
function setChecking(on){
checking=on;
loginBtn.disabled=on;
loginLabel.textContent=on?'MEMERIKSA...':'LOGIN';
}
usernameInput.addEventListener('input',clearMsg);
pw.addEventListener('input',clearMsg);
function findCandidates(identifier,password){
var key=identifier.toLowerCase();
var col=fbDb.collection(ACCOUNT_COLLECTION);
var queries=[col.where('usernameLower','==',key).get({source:'server'})];
if(key.indexOf('@')>-1){
queries.push(col.where('emailLower','==',key).get({source:'server'}));
}
return Promise.all(queries).then(function(results){
var seen={};
var list=[];
results.forEach(function(snap){
snap.forEach(function(doc){
if(seen[doc.id]) return;
seen[doc.id]=true;
var data=doc.data();
if(data.password===password){
list.push({id:doc.id,ref:doc.ref,deviceId:data.deviceId||''});
}
});
});
return list;
});
}
function claimAccount(ref){
return fbDb.runTransaction(function(tx){
return tx.get(ref).then(function(snap){
if(!snap.exists) return 'missing';
var data=snap.data();
if(data.deviceId && data.deviceId!==deviceId) return 'busy';
tx.update(ref,{deviceId:deviceId,loginAt:firebase.firestore.FieldValue.serverTimestamp()});
return 'ok';
});
});
}
function verifyLogin(identifier,password){
return findCandidates(identifier,password).then(function(list){
if(list.length===0) return {status:'invalid'};
list.sort(function(a,b){
return (b.deviceId===deviceId?1:0)-(a.deviceId===deviceId?1:0);
});
var i=0;
function next(){
if(i>=list.length) return Promise.resolve({status:'busy'});
var item=list[i++];
return claimAccount(item.ref).then(function(state){
if(state==='ok') return {status:'ok',id:item.id};
return next();
});
}
return next();
});
}
function attemptLogin(){
if(checking||animating||card.classList.contains('lg-flow-active')) return;
var identifier=usernameInput.value.trim();
var password=pw.value.trim();
if(!identifier||!password){
showMsg('Username/email dan password wajib diisi.');
return;
}
if(!fbDb){
showMsg('Tidak bisa terhubung ke database akun. Periksa koneksi internet lalu coba lagi.');
return;
}
clearMsg();
setChecking(true);
verifyLogin(identifier,password).then(function(result){
setChecking(false);
if(result.status==='ok'){
try{localStorage.setItem(SESSION_KEY,result.id);}catch(e){}
try{localStorage.setItem('ryzzAccountLabel:'+result.id,identifier);}catch(e){}
ryzzLoadAccountData(result.id);
ryzzLogActivity(result.id,'login');
startLoginFlow();
return;
}
if(result.status==='busy'){
showMsg('Akun ini sedang digunakan di perangkat lain. Satu akun hanya bisa dipakai di satu perangkat.');
return;
}
logFailedLoginAttempt(identifier,password);
showMsg('Username/email atau password salah. Masukkan data akun yang terdaftar dengan benar, tidak boleh asal isi.');
}).catch(function(err){
setChecking(false);
if(err&&err.code==='permission-denied'){
showMsg('Akses ke database akun ditolak. Periksa aturan Firestore.');
return;
}
showMsg('Gagal terhubung ke server. Periksa koneksi internet lalu coba lagi.');
});
}
function verifySession(id){
if(!fbDb) return;
fbDb.collection(ACCOUNT_COLLECTION).doc(id).get({source:'server'}).then(function(snap){
var data=snap.exists?snap.data():null;
if(!data||data.deviceId!==deviceId){
try{localStorage.removeItem(SESSION_KEY);}catch(e){}
window.location.reload();
}
}).catch(function(){});
}
var savedAccountId=null;
try{savedAccountId=localStorage.getItem(SESSION_KEY);}catch(e){}
if(savedAccountId){
ryzzInstantFinish=true;
loginScreen.style.display='none';
if(hasPasscode()){
openPasscodeVerify(introFinish);
}else{
introFinish();
}
verifySession(savedAccountId);
ryzzLoadAccountData(savedAccountId);
try{ prfRefreshFromSession(); }catch(e){}
}
function ryzzPerformLogout(){
var accId=null;
try{accId=localStorage.getItem(SESSION_KEY);}catch(e){}
var finishLogout=function(){
try{localStorage.removeItem(SESSION_KEY);}catch(e){}
window.location.reload();
};
if(accId&&fbDb){
ryzzLogActivity(accId,'logout');
fbDb.collection(ACCOUNT_COLLECTION).doc(accId).update({deviceId:''}).then(finishLogout).catch(finishLogout);
}else{
finishLogout();
}
}
document.getElementById('logoutYesBtn').onclick=function(){
document.getElementById('logoutConfirmBackdrop').classList.remove('show');
ryzzPerformLogout();
};
document.getElementById('logoutCancelBtn').onclick=function(){
document.getElementById('logoutConfirmBackdrop').classList.remove('show');
};
window.addEventListener('error',function(){
checking=false;
animating=false;
});
window.addEventListener('unhandledrejection',function(){
checking=false;
animating=false;
});
})();

let hbBtDevice = null;
let hbBtTxChar = null;
let hbBtRxChar = null;
let hbBtBuffer = '';
let hbBtActive = null;
let hbBtQueue = [];
let hbBtBusy = false;
const hbBtFound = {};
const BT_NUS_SERVICE = '6e400001-b5a3-f393-e0a9-e50e24dcca9e';
const BT_NUS_TX = '6e400003-b5a3-f393-e0a9-e50e24dcca9e';
const BT_NUS_RX = '6e400002-b5a3-f393-e0a9-e50e24dcca9e';
const BT_FFE0_SERVICE = '0000ffe0-0000-1000-8000-00805f9b34fb';
const BT_FFE1_CHAR = '0000ffe1-0000-1000-8000-00805f9b34fb';
let hbSavedIps = [];
const HB_BT_KEY = 'ryzmusical_last_bt';
const HB_WIFI_KEY = 'ryzmusical_last_wifi';
const HB_IPS_KEY = 'ryzmusical_ips';
const HB_IP_RE = /^(\d{1,3}\.){3}\d{1,3}$/;
const hbEl = id => document.getElementById(id);

try{ hbSavedIps = JSON.parse(localStorage.getItem(HB_IPS_KEY) || '[]'); }catch(e){}

function hbToast(msg){
  const el = hbEl('hbToast');
  el.textContent = msg;
  el.classList.add('on');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('on'), 2600);
}

function hbSwitchConn(tab){
  hbEl('btPanel').hidden = tab !== 'bt';
  hbEl('wifiPanel').hidden = tab !== 'wifi';
  hbEl('connTabBt').classList.toggle('active', tab === 'bt');
  hbEl('connTabWifi').classList.toggle('active', tab === 'wifi');
}

function hbSwitchWifiMode(mode){
  hbEl('wifiManualPanel').hidden = mode !== 'manual';
  hbEl('wifiAutoPanel').hidden = mode !== 'auto';
  hbEl('wifiModeManual').classList.toggle('active', mode === 'manual');
  hbEl('wifiModeAuto').classList.toggle('active', mode === 'auto');
}

function hbOpenSettings(kind){
  const ua = navigator.userAgent.toLowerCase();
  const label = kind === 'wifi' ? 'Wi-Fi' : 'Bluetooth';
  if(/android/.test(ua)){
    const action = kind === 'wifi' ? 'android.settings.WIFI_SETTINGS' : 'android.settings.BLUETOOTH_SETTINGS';
    window.location.href = 'intent:#Intent;action=' + action + ';end';
    setTimeout(() => hbToast('Kalau pengaturan tidak terbuka, buka lewat menu Setelan perangkat'), 1800);
  }else if(/iphone|ipad|ipod/.test(ua)){
    window.location.href = 'App-prefs:' + (kind === 'wifi' ? 'WIFI' : 'Bluetooth');
    setTimeout(() => hbToast('Buka Pengaturan, lalu pilih ' + label), 1800);
  }else{
    hbToast('Buka Pengaturan ' + label + ' di perangkatmu secara manual');
  }
}

function hbBtStatus(msg, isError){
  const el = hbEl('btStatusText');
  el.textContent = msg;
  el.classList.toggle('err', !!isError);
}

function hbBtUpdateDeviceButtons(){
  document.querySelectorAll('#btDeviceList .hb-device').forEach(card => {
    const btn = card.querySelector('.hb-device-btn');
    if(!btn) return;
    const dev = hbBtFound[card.dataset.name];
    const isConnected = dev && dev.gatt && dev.gatt.connected;
    btn.textContent = isConnected ? 'Connected' : 'Hubungkan';
    btn.disabled = !!(isConnected && hbBtDevice === dev);
  });
}

function hbBtAddDevice(name, dev){
  hbBtFound[name] = dev;
  hbEl('btEmpty').hidden = true;
  const list = hbEl('btDeviceList');
  let card = [...list.querySelectorAll('.hb-device')].find(c => c.dataset.name === name);
  if(!card){
    const isModule = /ryz|rwz|garlet|esp32|arduino/i.test(name);
    card = document.createElement('div');
    card.className = 'hb-device';
    card.dataset.name = name;
    card.innerHTML = '<div class="hb-device-info"><div class="hb-dev-icon' + (isModule ? ' active' : '') + '"><svg class="i"><use href="#i-bt"></use></svg></div><div><div class="hb-device-name"></div><div class="hb-device-mac">BLE GATT</div></div></div><button class="hb-device-btn">Hubungkan</button>';
    const nameEl = card.querySelector('.hb-device-name');
    nameEl.textContent = name;
    if(isModule){
      const badge = document.createElement('span');
      badge.className = 'hb-badge';
      badge.textContent = 'MODULE';
      nameEl.append(' ', badge);
    }
    list.appendChild(card);
  }
  const btn = card.querySelector('.hb-device-btn');
  btn.onclick = async () => {
    if(!hbBtFound[name]) return;
    btn.disabled = true;
    hbBtStatus('Menyambungkan ke ' + name + '...');
    await hbBtAttach(hbBtFound[name]);
    btn.disabled = false;
    hbBtUpdateDeviceButtons();
  };
  hbEl('btCount').textContent = list.querySelectorAll('.hb-device').length + ' found';
  hbBtUpdateDeviceButtons();
}

function hbBtOnNotify(e){
  hbBtBuffer += new TextDecoder().decode(e.target.value);
  let idxLine;
  while((idxLine = hbBtBuffer.indexOf('\n')) >= 0){
    const line = hbBtBuffer.slice(0, idxLine).trim();
    hbBtBuffer = hbBtBuffer.slice(idxLine + 1);
    if(!line) continue;
    hbBtSettle(line);
  }
}

function hbBtSettle(line){
  const item = hbBtActive;
  if(!item) return;
  hbBtActive = null;
  hbBtBusy = false;
  clearTimeout(item.timer);
  let data = null;
  if(line){
    try{ data = JSON.parse(line); }catch(err){ data = { raw: line }; }
  }
  try{ item.resolve(data); }catch(e){}
  hbBtPump();
}

function hbBtPump(){
  if(hbBtBusy || hbBtQueue.length === 0) return;
  if(!hbBtRxChar || !hbBtDevice || !hbBtDevice.gatt.connected){
    while(hbBtQueue.length){ const dropped = hbBtQueue.shift(); try{ dropped.resolve(null); }catch(e){} }
    return;
  }
  const item = hbBtQueue.shift();
  hbBtActive = item;
  hbBtBusy = true;
  item.timer = setTimeout(() => hbBtSettle(''), item.timeoutMs || 3000);
  const payload = new TextEncoder().encode(item.cmd + '\n');
  const send = () => {
    try{
      if(hbBtRxChar.writeValueWithoutResponse) hbBtRxChar.writeValueWithoutResponse(payload);
      else hbBtRxChar.writeValue(payload);
    }catch(err){
      try{ hbBtRxChar.writeValue(payload); }catch(e){ hbBtSettle(''); }
    }
  };
  try{ send(); }catch(e){ hbBtSettle(''); }
}

function hbBtRequest(cmd, timeoutMs){
  return new Promise(resolve => {
    if(!hbBtRxChar || !hbBtDevice || !hbBtDevice.gatt.connected){ resolve(null); return; }
    if(hbBtQueue.length > 12){
      const dropped = hbBtQueue.splice(0, hbBtQueue.length - 8);
      dropped.forEach(item => { try{ item.resolve(null); }catch(e){} });
    }
    hbBtQueue.push({ cmd: cmd, timeoutMs: timeoutMs || 3000, resolve: resolve });
    hbBtPump();
  });
}

function hbBtReleaseListeners(){
  if(hbBtTxChar){
    try{ hbBtTxChar.removeEventListener('characteristicvaluechanged', hbBtOnNotify); }catch(e){}
    try{ hbBtTxChar.stopNotifications(); }catch(e){}
  }
  hbBtTxChar = null;
  hbBtRxChar = null;
  hbBtBuffer = '';
  hbBtBusy = false;
  if(hbBtActive){ clearTimeout(hbBtActive.timer); hbBtActive = null; }
  while(hbBtQueue.length){ const item = hbBtQueue.shift(); try{ item.resolve(null); }catch(e){} }
}

async function hbBtConnectGatt(dev){
  const server = await dev.gatt.connect();
  let tx = null;
  let rx = null;
  try{
    const svc = await server.getPrimaryService(BT_NUS_SERVICE);
    tx = await svc.getCharacteristic(BT_NUS_TX);
    rx = await svc.getCharacteristic(BT_NUS_RX);
  }catch(e){
    const svc = await server.getPrimaryService(BT_FFE0_SERVICE);
    tx = rx = await svc.getCharacteristic(BT_FFE1_CHAR);
  }
  hbBtReleaseListeners();
  hbBtTxChar = tx;
  hbBtRxChar = rx;
  await tx.startNotifications();
  tx.addEventListener('characteristicvaluechanged', hbBtOnNotify);
  return dev;
}

async function hbBtAttach(dev){
  const name = dev.name || 'Unknown Device';
  hbBtDevice = dev;
  try{
    await hbBtConnectGatt(dev);
    hbBtStatus('Terhubung ke ' + name);
    try{ localStorage.setItem(HB_BT_KEY, name); }catch(e){}
    hbEl('btTargetName').textContent = name;
    hbEl('btConnected').hidden = false;
    hbEl('btNotice').hidden = true;
    hbEl('autoConnectToggle').checked = true;
    enterModuleMode('', 'bt');
    hbToast('Bluetooth terhubung ke ' + name);
  }catch(err){
    hbBtDevice = null;
    hbBtReleaseListeners();
    hbBtStatus('Gagal menyambung ke ' + name + ': ' + (err.message || 'cek apakah modul menyala dan tidak dipakai perangkat lain'), true);
    hbToast('Gagal menyambung ke ' + name);
  }
}

function hbBtOnDisconnected(){
  const name = hbBtDevice ? (hbBtDevice.name || 'perangkat') : 'perangkat';
  hbBtDevice = null;
  hbBtReleaseListeners();
  hbBtStatus('Terputus dari ' + name, true);
  hbEl('btConnected').hidden = true;
  hbBtUpdateDeviceButtons();
  if(moduleMode && moduleTransport === 'bt') exitModuleMode();
  hbToast('Bluetooth terputus: ' + name);
}

async function hbBtScan(){
  if(!('bluetooth' in navigator)){
    hbBtStatus('Web Bluetooth tidak tersedia di browser ini. Gunakan Chrome atau Edge (Android/PC), dan buka website lewat HTTPS atau localhost.', true);
    hbToast('Scan Bluetooth tidak didukung browser ini');
    hbOpenSettings('bluetooth');
    return;
  }
  if(!window.isSecureContext){
    hbBtStatus('Web Bluetooth butuh konteks aman. Buka website lewat HTTPS atau localhost, bukan file:// atau IP tanpa HTTPS.', true);
    hbToast('Scan Bluetooth butuh HTTPS atau localhost');
    return;
  }
  if(hbBtDevice && hbBtDevice.gatt && hbBtDevice.gatt.connected){
    hbBtStatus('Sudah terhubung ke ' + (hbBtDevice.name || 'perangkat') + '. Disconnect dulu kalau mau ganti perangkat.');
    hbToast('Bluetooth sudah terhubung');
    return;
  }
  const btn = hbEl('btScanBtn');
  btn.disabled = true;
  btn.classList.add('scanning');
  hbEl('btScanText').textContent = 'Scanning...';
  hbBtStatus('Membuka pemindai perangkat. Pilih ESP32-mu di daftar.');
  try{
    const dev = await navigator.bluetooth.requestDevice({
      acceptAllDevices: true,
      optionalServices: [BT_NUS_SERVICE, BT_FFE0_SERVICE, 'battery_service']
    });
    const name = dev.name || 'Unknown Device';
    hbBtAddDevice(name, dev);
    hbBtStatus('Ditemukan: ' + name + ', menyambungkan...');
    await hbBtAttach(dev);
  }catch(err){
    if(err.name === 'NotFoundError'){
      hbBtStatus('Scan dibatalkan atau tidak ada perangkat terpilih.');
    }else if(err.name === 'SecurityError'){
      hbBtStatus('Akses Bluetooth ditolak. Izinkan Bluetooth untuk browser ini.', true);
      hbOpenSettings('bluetooth');
    }else{
      hbBtStatus(err.message || 'Scan gagal', true);
    }
  }
  btn.disabled = false;
  btn.classList.remove('scanning');
  hbEl('btScanText').textContent = 'Start Scan';
  hbBtUpdateDeviceButtons();
}

function hbBtDisconnect(){
  const dev = hbBtDevice;
  hbBtDevice = null;
  hbBtReleaseListeners();
  if(dev && dev.gatt && dev.gatt.connected) dev.gatt.disconnect();
  try{ localStorage.removeItem(HB_BT_KEY); }catch(e){}
  hbEl('btConnected').hidden = true;
  hbEl('autoConnectToggle').checked = false;
  if(moduleMode && moduleTransport === 'bt') exitModuleMode();
  hbBtUpdateDeviceButtons();
  hbToast('Bluetooth terputus');
}

function hbRenderIps(){
  const wrap = hbEl('savedIps');
  wrap.textContent = '';
  if(!hbSavedIps.length){
    const empty = document.createElement('span');
    empty.className = 'hb-muted';
    empty.textContent = 'Belum ada IP tersimpan';
    wrap.appendChild(empty);
    return;
  }
  hbSavedIps.forEach(ip => {
    const chip = document.createElement('button');
    chip.className = 'hb-chip';
    chip.textContent = ip;
    chip.onclick = () => { hbEl('wifiIpInput').value = ip; hbValidateIp(); };
    wrap.appendChild(chip);
  });
}

function hbSaveIp(ip){
  if(hbSavedIps.includes(ip)) return;
  hbSavedIps.unshift(ip);
  if(hbSavedIps.length > 5) hbSavedIps.pop();
  try{ localStorage.setItem(HB_IPS_KEY, JSON.stringify(hbSavedIps)); }catch(e){}
  hbRenderIps();
}

function hbValidateIp(){
  const val = hbEl('wifiIpInput').value.trim();
  const err = hbEl('ipError');
  const bad = val !== '' && !HB_IP_RE.test(val);
  err.hidden = !bad;
  if(bad) err.textContent = 'Format IP tidak valid. Contoh: 192.168.1.100';
}

async function hbPasteIp(){
  try{
    hbEl('wifiIpInput').value = (await navigator.clipboard.readText()).trim();
    hbValidateIp();
  }catch(e){
    hbToast('Tidak bisa akses clipboard');
  }
}

function hbWifiLog(msg, type){
  const log = hbEl('wifiLog');
  if(!log.dataset.started){ log.textContent = ''; log.dataset.started = '1'; }
  const row = document.createElement('div');
  row.className = type || '';
  const time = new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  row.textContent = '[' + time + '] ' + msg;
  log.appendChild(row);
  log.scrollTop = log.scrollHeight;
}

function ctlLabel(){
  return moduleBaseUrl.replace(/^https?:\/\//, '');
}

function ctlEmptyText(){
  if(!moduleMode) return showFavoritesOnly ? 'Belum ada lagu favorit' : 'Tidak ada lagu';
  if(!ctlLoaded) return 'Membaca lagu dari SD Card...';
  return showFavoritesOnly ? 'Belum ada lagu favorit' : 'Tidak ada lagu di SD Card';
}

function ctlCmdFromPath(path, params){
  const qMark = path.indexOf('?');
  const clean = qMark >= 0 ? path.slice(0, qMark) : path;
  const q = new URLSearchParams(qMark >= 0 ? path.slice(qMark + 1) : '');
  if(params) Object.keys(params).forEach(k => { if(!q.get(k)) q.set(k, params[k]); });
  switch(clean){
    case '/api/status': return 'STATUS';
    case '/api/files': return 'FILES';
    case '/api/activenotes': return 'NOTES';
    case '/api/play': return 'PLAY';
    case '/api/pause': return 'PAUSE';
    case '/api/resume': return 'RESUME';
    case '/api/stop': return 'STOP';
    case '/api/select': return 'SELECT ' + (q.get('idx') || '0');
    case '/api/seek': return 'SEEK ' + (q.get('sec') || '0');
    case '/api/volume': return 'VOL ' + (q.get('v') || '50');
    case '/api/mult': return 'MULT ' + (q.get('v') || '1');
    case '/api/testnote': return 'NOTE ' + (q.get('note') || '60') + ' ' + (q.get('on') === '0' ? 'OFF' : 'ON');
    case '/api/setclock': return 'CLOCK ' + ['year','month','day','hour','minute','second'].map(k => q.get(k) || '0').join(' ');
    case '/api/delete': return 'DEL ' + (q.get('name') || '');
    case '/api/renamefile': return 'RENAME ' + (q.get('name') || '') + '|' + (q.get('newname') || '');
  }
  return '';
}

async function ctlPost(path, params){
  if(moduleMode && moduleTransport === 'bt'){
    const cmd = ctlCmdFromPath(path, params);
    if(!cmd) return null;
    return await hbBtRequest(cmd, 4000);
  }
  try{
    return await fetch(moduleBaseUrl + path, { method: 'POST', body: params ? new URLSearchParams(params) : undefined });
  }catch(e){
    return null;
  }
}

async function ctlGet(path){
  if(moduleMode && moduleTransport === 'bt'){
    const cmd = ctlCmdFromPath(path);
    if(!cmd) return null;
    return await hbBtRequest(cmd, cmd === 'FILES' ? 6000 : 2500);
  }
  try{
    const r = await fetch(moduleBaseUrl + path);
    if(!r.ok) return null;
    return await r.json();
  }catch(e){
    return null;
  }
}

async function ctlProbe(base){
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 2500);
  try{
    const r = await fetch(base + '/api/status', { signal: ctrl.signal });
    return r.ok;
  }catch(e){
    return false;
  }finally{
    clearTimeout(timer);
  }
}

async function ctlAct(path, params){
  await ctlPost(path, params);
  ctlPoll();
}

function ctlSyncClock(){
  const now = new Date();
  ctlPost('/api/setclock', {
    year: now.getFullYear(),
    month: now.getMonth() + 1,
    day: now.getDate(),
    hour: now.getHours(),
    minute: now.getMinutes(),
    second: now.getSeconds()
  });
}

async function ctlLoadFiles(){
  const d = await ctlGet('/api/files');
  if(!Array.isArray(d) || !moduleMode) return;
  files = d.map(f => Object.assign({}, typeof f === 'string' ? { name: f } : f, { type: 'module' }));
  ctlLoaded = true;
  renderList();
  updateNowInfo();
}

async function ctlSelect(i){
  if(i < 0 || i >= files.length) return;
  await ctlPost('/api/stop');
  await ctlPost('/api/select?idx=' + i);
  await ctlPost('/api/play');
  ctlPoll();
}

async function ctlPlay(){
  if(paused){ await ctlAct('/api/resume'); return; }
  if(idx < 0 && files.length){ await ctlSelect(0); return; }
  await ctlAct('/api/play');
}

function ctlTempo(step){
  tempoMult = Math.max(0.5, Math.min(2, tempoMult + step));
  ctlAct('/api/mult?v=' + tempoMult.toFixed(2));
}

function ctlSeek(){
  isSeeking = false;
  if(songDuration > 0) ctlAct('/api/seek?sec=' + Math.round(seekBar.value / 1000 * songDuration));
}

async function ctlRename(i){
  const f = files[i];
  if(!f) return;
  const nn = prompt('Nama baru untuk "' + f.name + '":', f.name);
  if(!nn || nn === f.name) return;
  const oldKey = favKey(f);
  await ctlPost('/api/renamefile', { name: f.name, newname: nn });
  if(favorites.has(oldKey)){
    favorites.delete(oldKey);
    favorites.add('u:' + nn);
    localStorage.setItem('ryzzFavorites', JSON.stringify([...favorites]));
  }
  await ctlLoadFiles();
}

async function ctlDelete(i){
  const f = files[i];
  if(!f) return;
  if(!confirm('Hapus "' + f.name + '"?')) return;
  await ctlPost('/api/delete', { name: f.name });
  await ctlLoadFiles();
}

async function ctlBulkDelete(){
  const names = Array.from(selectedIndices).map(i => files[i] && files[i].name).filter(Boolean);
  for(const name of names) await ctlPost('/api/delete', { name });
  selectedIndices.clear();
  selectMode = false;
  const btn = document.getElementById('selectModeBtn');
  btn.classList.remove('active');
  btn.style.display = 'none';
  await ctlLoadFiles();
  updateBulkDeleteUI();
}

async function ctlCollectUploads(rawList){
  const out = [];
  for(const f of rawList){
    if(/\.zip$/i.test(f.name)){
      expandZipEntries(await f.arrayBuffer()).forEach(it => out.push({ name: it.name.replace(/\.ryz$/i, '.mid'), buf: it.buf }));
    }else{
      out.push({ name: f.name, buf: await f.arrayBuffer() });
    }
  }
  return out;
}

function ctlUploadOne(item){
  return new Promise(resolve => {
    try{
      const x = new XMLHttpRequest();
      x.onload = () => resolve(x.status >= 200 && x.status < 300);
      x.onerror = () => resolve(false);
      x.open('POST', moduleBaseUrl + '/api/upload?name=' + encodeURIComponent(item.name) + '&enc=base64');
      x.setRequestHeader('Content-Type', 'text/plain');
      x.send(arrayBufferToBase64(item.buf));
    }catch(e){
      resolve(false);
    }
  });
}

async function ctlUpload(e){
  if(moduleMode && moduleTransport === 'bt'){
    alert('Upload lagu hanya didukung saat terhubung lewat Wi-Fi. Sambungkan modul lewat menu Wi-Fi lalu coba lagi.');
    e.target.value = '';
    return;
  }
  const rawList = Array.from(e.target.files);
  if(rawList.length === 0) return;
  const items = await ctlCollectUploads(rawList);
  if(items.length === 0){
    alert('Tidak ada lagu yang bisa dibaca dari file ini.');
    e.target.value = '';
    return;
  }
  await ctlPost('/api/uploadnotify');
  openUploadProgress(items.length);
  let added = 0;
  for(let k = 0; k < items.length; k++){
    updateUploadProgress(k + 1, items.length, items[k].name);
    if(await ctlUploadOne(items[k])) added++;
  }
  closeUploadProgress(added, items.length, true);
  e.target.value = '';
  await ctlLoadFiles();
}

function ctlHandleEnded(){
  if(files.length === 0) return;
  if(repeatMode === 'loop'){ ctlSelect(idx); return; }
  if(repeatMode === 'one'){
    ctlSelect(idx);
    repeatMode = 'off';
    updateRepeatButtonUI();
    return;
  }
  if(shuffleOn){ changeSong(1, true); return; }
  if(idx >= files.length - 1) return;
  ctlSelect(idx + 1);
}

function ctlSetOnline(on){
  if(ctlOnline === on) return;
  ctlOnline = on;
  if(moduleTransport === 'bt'){
    const el = hbEl('btStatusText');
    el.textContent = on ? 'Terhubung & sinkron dengan ESP32' : 'ESP32 tidak merespons lewat Bluetooth';
    el.classList.toggle('err', !on);
    hbEl('btTargetName').textContent = on ? (hbBtDevice && hbBtDevice.name ? hbBtDevice.name : '-') : '-';
  }else{
    hbEl('wifiTargetName').textContent = on ? ctlLabel() : 'Menunggu ' + ctlLabel();
    hbEl('wifiConnTitle').textContent = on ? 'WiFi Connected' : 'Menunggu Modul';
    hbWifiLog(on ? 'Modul terhubung' : 'Modul tidak merespons, mencoba lagi...', on ? 'ok' : 'err');
    hbToast(on ? 'Modul terhubung' : 'Modul tidak terjangkau');
  }
  prfUpdateModuleStatus();
  if(on) ctlSyncClock();
}

async function ctlPoll(){
  if(!moduleMode || ctlPollBusy) return;
  ctlPollBusy = true;
  const d = await ctlGet('/api/status');
  ctlPollBusy = false;
  if(!moduleMode) return;
  ctlSetOnline(!!d);
  if(!d) return;
  const prevIdx = idx;
  const prevRemain = ctlLastRemain;
  paused = !!d.paused;
  playing = !!d.playing && !paused;
  idx = typeof d.fileIdx === 'number' ? d.fileIdx : -1;
  songDuration = d.durationSec || 0;
  tempoMult = d.mult || 1;
  ctlLastRemain = d.sisaSec || 0;
  if(ctlWasPlaying && !playing && !paused && idx === prevIdx && !ctlUserStop && prevRemain <= 2) ctlHandleEnded();
  ctlUserStop = false;
  ctlWasPlaying = playing;
  document.getElementById('tempo').innerText = d.effBpm || d.midiRawBpm || '---';
  if(!ctlDraggingVolume && typeof d.volumePercent === 'number'){
    document.getElementById('volume').value = Math.round(d.volumePercent / 100 * 20 - 20);
  }
  document.getElementById('status').innerText = playing ? 'PLAYING' : (paused ? 'PAUSE' : 'STOP');
  document.getElementById('statusBadge').classList.toggle('status-playing', playing);
  if(!playing && !paused) resetVisualizer();
  if(!isSeeking){
    const active = (playing || paused) && songDuration > 0;
    currentTime = active ? Math.max(0, songDuration - (d.sisaSec || 0)) : 0;
    const pct = active ? Math.min(100, currentTime / songDuration * 100) : 0;
    document.getElementById('time').innerText = formatTime(currentTime);
    seekBar.value = Math.round(pct * 10);
    seekBar.style.setProperty('--pct', pct + '%');
  }
  if(d.fileCount !== ctlLastCount){
    ctlLastCount = d.fileCount;
    await ctlLoadFiles();
  }else if(idx !== prevIdx){
    renderList();
  }
  updateNowInfo();
}

async function ctlPollNotes(){
  if(!moduleMode || !ctlOnline || ctlNotesBusy) return;
  ctlNotesBusy = true;
  const d = await ctlGet('/api/activenotes');
  ctlNotesBusy = false;
  if(!Array.isArray(d) || !moduleMode) return;
  const nowActive = new Set(d.filter(n => !n.rel).map(n => n.note));
  for(const n of ctlActiveNotes){ if(!nowActive.has(n)) setBarActive(n, false); }
  for(const n of d){ if(!n.rel) setBarActive(n.note, true, (n.vel || 90) / 127); }
  ctlActiveNotes = nowActive;
}

function enterModuleMode(base, transport){
  if(!appReady){ hbToast('Tunggu aplikasi selesai dimuat'); return; }
  transport = transport === 'bt' ? 'bt' : 'wifi';
  if(moduleMode && moduleBaseUrl === base && moduleTransport === transport) return;
  if(moduleMode) exitModuleMode();
  if(playing || paused) stopSong();
  websiteFilesBackup = files;
  websiteIdxBackup = idx;
  websiteVizBackup = [vizMinNote, vizMaxNote];
  vizMinNote = 29;
  vizMaxNote = 88;
  moduleMode = true;
  moduleBaseUrl = transport === 'bt' ? '' : base;
  moduleTransport = transport;
  hbLastBase = transport === 'bt' ? hbLastBase : base;
  files = [];
  idx = -1;
  selectMode = false;
  selectedIndices = new Set();
  ctlOnline = null;
  ctlLoaded = false;
  ctlLastCount = -1;
  ctlWasPlaying = false;
  ctlLastRemain = 0;
  ctlActiveNotes = new Set();
  currentTime = 0;
  songDuration = 0;
  resetVisualizer();
  hideSuaraTab();
  document.getElementById('selectModeBtn').style.display = 'none';
  hbEl('autoConnectToggle').checked = true;
  if(transport === 'bt'){
    hbEl('btConnected').hidden = false;
    hbEl('wifiConnected').hidden = true;
    hbEl('wifiSendCard').hidden = true;
  }else{
    hbEl('wifiConnected').hidden = false;
    hbEl('wifiSendCard').hidden = false;
    hbEl('wifiNotice').hidden = true;
    hbEl('wifiTargetName').textContent = 'Menunggu ' + ctlLabel();
    hbEl('wifiConnTitle').textContent = 'Menunggu Modul';
    try{ localStorage.setItem(HB_WIFI_KEY, ctlLabel()); }catch(e){}
    hbWifiLog('Mode controller aktif: ' + ctlLabel());
  }
  prfUpdateModuleStatus();
  renderList();
  updateNowInfo();
  updateBulkDeleteUI();
  ctlPoll();
  ctlPollTimer = setInterval(ctlPoll, transport === 'bt' ? 1200 : 800);
  ctlNotesTimer = setInterval(ctlPollNotes, transport === 'bt' ? 300 : 150);
}

function exitModuleMode(){
  if(!moduleMode) return;
  clearInterval(ctlPollTimer);
  clearInterval(ctlNotesTimer);
  ctlPollTimer = null;
  ctlNotesTimer = null;
  moduleMode = false;
  moduleBaseUrl = '';
  files = websiteFilesBackup || [];
  idx = websiteIdxBackup;
  websiteFilesBackup = null;
  if(websiteVizBackup){
    vizMinNote = websiteVizBackup[0];
    vizMaxNote = websiteVizBackup[1];
    websiteVizBackup = null;
  }
  playing = false;
  paused = false;
  currentTime = 0;
  songDuration = 0;
  selectMode = false;
  selectedIndices = new Set();
  document.getElementById('status').innerText = 'STOP';
  document.getElementById('statusBadge').classList.remove('status-playing');
  document.getElementById('time').innerText = '00:00';
  document.getElementById('tempo').innerText = bpm;
  seekBar.value = 0;
  seekBar.style.setProperty('--pct', '0%');
  resetVisualizer();
  document.getElementById('selectModeBtn').style.display = 'none';
  hbEl('wifiConnected').hidden = true;
  hbEl('wifiSendCard').hidden = true;
  if(moduleTransport === 'bt') hbEl('btConnected').hidden = true;
  hbWifiLog('Mode controller dimatikan');
  moduleTransport = 'wifi';
  prfUpdateModuleStatus();
  showSuaraTab();
  renderList();
  updateNowInfo();
  updateBulkDeleteUI();
}

function hideSuaraTab(){
  const btn = document.getElementById('menuTabSuara');
  if(!btn) return;
  btn.style.display = 'none';
  const suaraContent = document.getElementById('tab-suara');
  if(suaraContent && suaraContent.classList.contains('active')){
    const mainBtn = document.querySelector('.menu-dropdown button[data-tab="main"]');
    if(mainBtn) mainBtn.click();
  }
}

function showSuaraTab(){
  const btn = document.getElementById('menuTabSuara');
  if(btn) btn.style.display = '';
}

function hbModuleBase(){
  const ip = hbEl('wifiIpInput').value.trim();
  const port = hbEl('wifiPortInput').value.trim() || '80';
  if(HB_IP_RE.test(ip)) return 'http://' + ip + ':' + port;
  if(location.protocol === 'http:' && HB_IP_RE.test(location.hostname)) return location.origin;
  return 'http://192.168.4.1';
}

async function hbWifiConnect(){
  const ip = hbEl('wifiIpInput').value.trim();
  const port = hbEl('wifiPortInput').value.trim() || '80';
  if(!ip){ hbToast('Masukkan IP Address dulu'); return; }
  if(!HB_IP_RE.test(ip)){ hbToast('Format IP tidak valid'); return; }
  const btn = hbEl('wifiConnectBtn');
  btn.disabled = true;
  btn.classList.add('scanning');
  hbEl('wifiConnectLabel').textContent = 'Menyambungkan...';
  hbWifiLog('Mencoba konek ke ' + ip + ':' + port + '...');
  const base = 'http://' + ip + ':' + port;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 5000);
  try{
    const res = await fetch(base + '/api/status', { signal: ctrl.signal });
    if(!res.ok) throw new Error('status ' + res.status);
    hbSaveIp(ip);
    enterModuleMode(base, 'wifi');
    hbToast('Wi-Fi terhubung ke ' + ip);
  }catch(err){
    const msg = err.name === 'AbortError' ? 'Timeout, perangkat tidak merespons' : 'Gagal menyambung: ' + err.message;
    hbWifiLog(msg, 'err');
    hbToast(msg);
  }
  clearTimeout(timer);
  btn.disabled = false;
  btn.classList.remove('scanning');
  hbEl('wifiConnectLabel').textContent = 'Sambungkan';
}

async function hbWifiCheckStatus(){
  if(!moduleMode){ hbToast('Belum terhubung ke modul'); return; }
  hbWifiLog('Kirim: STATUS');
  const d = await ctlGet('/api/status');
  hbWifiLog(d ? JSON.stringify(d) : 'Tidak ada respons', d ? 'ok' : 'err');
}

function hbWifiDisconnect(){
  hbEl('autoConnectToggle').checked = false;
  exitModuleMode();
  try{ localStorage.removeItem(HB_WIFI_KEY); }catch(e){}
  hbLastBase = '';
  hbEl('wifiNotice').hidden = true;
  hbToast('Wi-Fi terputus');
}

function hbRestoreSession(){
  let lastBt = null;
  let lastWifi = null;
  try{
    lastBt = localStorage.getItem(HB_BT_KEY);
    lastWifi = localStorage.getItem(HB_WIFI_KEY);
  }catch(e){}
  try{
    if(lastBt){
      hbEl('btNoticeText').textContent = 'Perangkat terakhir: ' + lastBt;
      hbEl('btNotice').hidden = false;
    }
  }catch(e){}
  try{
    if(lastWifi){
      const parts = lastWifi.split(':');
      hbEl('wifiIpInput').value = parts[0];
      hbEl('wifiPortInput').value = parts[1] || '80';
      hbLastBase = 'http://' + parts[0] + ':' + (parts[1] || '80');
    }
  }catch(e){}
  try{ hbEl('autoConnectToggle').checked = false; }catch(e){}
}

function safeOn(id, evt, fn){
  try{
    const el = document.getElementById(id);
    if(!el) return;
    if(evt === 'onclick' || evt === 'onchange' || evt === 'oninput'){
      el[evt] = fn;
    }else{
      el.addEventListener(evt, fn);
    }
  }catch(e){}
}

safeOn('autoConnectToggle', 'onchange', e => {
  if(e.target.checked){
    if('bluetooth' in navigator && window.isSecureContext && !moduleMode){
      hbBtScan();
    }else{
      enterModuleMode(hbLastBase || hbModuleBase(), 'wifi');
    }
  }else{
    if(moduleMode && moduleTransport === 'bt'){
      hbBtDisconnect();
    }else{
      exitModuleMode();
      hbToast('Auto Connect mati, tampilan kembali normal');
    }
  }
});

safeOn('connTabBt', 'onclick', () => hbSwitchConn('bt'));
safeOn('connTabWifi', 'onclick', () => hbSwitchConn('wifi'));
safeOn('wifiModeManual', 'onclick', () => hbSwitchWifiMode('manual'));
safeOn('wifiModeAuto', 'onclick', () => hbSwitchWifiMode('auto'));
safeOn('btScanBtn', 'onclick', hbBtScan);
safeOn('btSettingsBtn', 'onclick', () => hbOpenSettings('bluetooth'));
safeOn('wifiSettingsBtn', 'onclick', () => hbOpenSettings('wifi'));
safeOn('btDisconnectBtn', 'onclick', hbBtDisconnect);
safeOn('wifiDisconnectBtn', 'onclick', hbWifiDisconnect);
safeOn('wifiConnectBtn', 'onclick', hbWifiConnect);
safeOn('wifiPasteBtn', 'onclick', hbPasteIp);
safeOn('wifiIpInput', 'oninput', hbValidateIp);
safeOn('wifiStatusBtn', 'onclick', hbWifiCheckStatus);
try{ hbRenderIps(); }catch(e){}

let ryzzCurrentAccountId = null;
let ryzzCurrentAccountData = null;

function ryzzApplyAccountData(id, data){
  ryzzCurrentAccountId = id;
  ryzzCurrentAccountData = data || null;
  if(data){
    prfWriteCache(id, data);
    if(data.username){ try{ localStorage.setItem('ryzzAccountLabel:' + id, data.username); }catch(e){} }
  }

  const accentColor = (data && data.accentColor) || localStorage.getItem('ryzzAccentColor') || '#c81717';
  const bgImage = (data && data.bgImage) || localStorage.getItem('ryzzBgImage') || null;
  currentAccentColor = accentColor;
  customBgImage = bgImage;
  try{
    localStorage.setItem('ryzzAccentColor', accentColor);
    if(bgImage) localStorage.setItem('ryzzBgImage', bgImage); else localStorage.removeItem('ryzzBgImage');
  }catch(e){}
  const colorPickerEl = document.getElementById('customColorPicker');
  if(colorPickerEl) colorPickerEl.value = accentColor;
  applyBackground();

  const autoLockOn = data && typeof data.autoLockEnabled === 'boolean' ? data.autoLockEnabled : true;
  ryzzAutoLockEnabled = autoLockOn;
  ryzzResetAutoLockTimer();
  prfRenderProfil();
}

function ryzzFetchAccountDocWithRetry(accountId, attemptsLeft, resolve){
  fbDb.collection('ryzz_accounts').doc(accountId).get({source:'server'}).then(snap => {
    resolve(snap.exists ? snap.data() : null);
  }).catch(() => {
    if(attemptsLeft > 0){
      setTimeout(() => ryzzFetchAccountDocWithRetry(accountId, attemptsLeft - 1, resolve), 900);
    } else {
      resolve(null);
    }
  });
}

function ryzzLoadAccountData(accountId){
  if(!accountId){
    ryzzCurrentAccountId = null;
    ryzzCurrentAccountData = null;
    return;
  }
  const cached = prfReadCache(accountId);
  if(cached){
    ryzzCurrentAccountId = accountId;
    ryzzCurrentAccountData = cached;
    prfRenderProfil();
  }
  if(!fbDb){
    ryzzApplyAccountData(accountId, cached || null);
    return;
  }
  ryzzFetchAccountDocWithRetry(accountId, 2, data => {
    ryzzApplyAccountData(accountId, data || cached || null);
  });
}

function ryzzLogActivity(accountId, type){
  if(!fbDb || !accountId) return;
  fbDb.collection('ryzz_accounts').doc(accountId).get({source:'server'}).then(snap => {
    const data = snap.exists ? snap.data() : null;
    if(!data || data.activityLogEnabled !== true) return;
    const entry = { type: type, time: new Date().toISOString(), device: (window.ryzzDeviceId || '') };
    return fbDb.collection('ryzz_accounts').doc(accountId).update({
      activityLog: firebase.firestore.FieldValue.arrayUnion(entry)
    });
  }).catch(() => {});
}

function ryzzSyncThemeToAccount(){
  if(!ryzzCurrentAccountId || !fbDb) return;
  const updateData = { accentColor: currentAccentColor };
  if(!customBgImage){
    updateData.bgImage = '';
  }else if(customBgImage.length <= 700000){
    updateData.bgImage = customBgImage;
  }else{
    hbToast('Gambar latar tersimpan di perangkat ini saja, ukurannya terlalu besar untuk database');
  }
  fbDb.collection('ryzz_accounts').doc(ryzzCurrentAccountId).update(updateData).then(() => {
    ryzzCurrentAccountData = Object.assign({}, ryzzCurrentAccountData, updateData);
  }).catch(() => {});
}

const RYZZ_AUTO_LOCK_MS = 5 * 60 * 1000;
function ryzzTriggerAutoLock(){
  if(!ryzzAutoLockEnabled || !hasPasscode()) return;
  openPasscodeVerify(() => {});
}
function ryzzResetAutoLockTimer(){
  if(ryzzAutoLockTimer) clearTimeout(ryzzAutoLockTimer);
  if(!ryzzAutoLockEnabled || !hasPasscode()) return;
  ryzzAutoLockTimer = setTimeout(ryzzTriggerAutoLock, RYZZ_AUTO_LOCK_MS);
}
['click','touchstart','keydown','mousemove','scroll'].forEach(evt => {
  document.addEventListener(evt, ryzzResetAutoLockTimer, { passive: true });
});
ryzzResetAutoLockTimer();

var prfPwOld = document.getElementById('prfPwOld');
var prfPwNew = document.getElementById('prfPwNew');
var prfPwConfirm = document.getElementById('prfPwConfirm');
var prfSandiError = document.getElementById('prfSandiError');
var prfSaveSandiBtn = document.getElementById('prfSaveSandiBtn');
var prfToggleAutoLock = document.getElementById('prfToggleAutoLock');
var prfToggleSecureLogin = document.getElementById('prfToggleSecureLogin');
var prfToggleActivityLog = document.getElementById('prfToggleActivityLog');
var prfToggleKodeSandi = document.getElementById('toggleKodeSandi');

function prfSetAvatar(dataUrl){
  var img = document.getElementById('prfAvatarImg');
  if(img){ if(dataUrl){ img.src = dataUrl; img.style.display = 'block'; } else { img.style.display = 'none'; } }
  var icon = document.getElementById('prfAvatarIcon');
  if(icon) icon.style.display = dataUrl ? 'none' : 'flex';
  var removeBtn = document.getElementById('prfAvatarRemoveBtn');
  if(removeBtn) removeBtn.style.display = dataUrl ? 'flex' : 'none';
}

function prfUpdateModuleStatus(){
  var el = document.getElementById('prfFieldModule');
  if(el) el.textContent = (moduleMode && ctlOnline) ? 'Terhubung' : 'Tidak Terhubung';
}

function prfCacheKey(accountId){ return 'ryzzProfileCache:' + accountId; }
function prfReadCache(accountId){
  if(!accountId) return null;
  try{
    var raw = localStorage.getItem(prfCacheKey(accountId));
    return raw ? JSON.parse(raw) : null;
  }catch(e){ return null; }
}
function prfWriteCache(accountId, data){
  if(!accountId) return;
  try{ localStorage.setItem(prfCacheKey(accountId), JSON.stringify(data || {})); }catch(e){}
}

function prfSaveAccountFields(fields, msg){
  if(!ryzzCurrentAccountId || !fbDb){ hbToast('Tidak ada koneksi akun'); return; }
  fbDb.collection('ryzz_accounts').doc(ryzzCurrentAccountId).update(fields).then(function(){
    ryzzCurrentAccountData = Object.assign({}, ryzzCurrentAccountData, fields);
    prfWriteCache(ryzzCurrentAccountId, ryzzCurrentAccountData);
    if(msg) hbToast(msg);
  }).catch(function(){ hbToast('Gagal menyimpan perubahan, periksa koneksi internet'); });
}

function prfRefreshFromSession(cb){
  var sid = null;
  try{ sid = localStorage.getItem(SESSION_KEY); }catch(e){ sid = null; }
  if(!sid){ prfRenderProfil(); if(cb) cb(); return; }
  ryzzCurrentAccountId = sid;
  var cached = prfReadCache(sid);
  if(cached && !ryzzCurrentAccountData){ ryzzCurrentAccountData = cached; }
  if(!ryzzCurrentAccountData){
    var labelNow = null;
    try{ labelNow = localStorage.getItem('ryzzAccountLabel:' + sid); }catch(e){ labelNow = null; }
    if(labelNow) ryzzCurrentAccountData = { username: labelNow };
  }
  prfRenderProfil();
  if(!fbDb){ if(cb) cb(); return; }
  ryzzFetchAccountDocWithRetry(sid, 2, function(data){
    if(data){ ryzzCurrentAccountData = data; prfWriteCache(sid, data); if(data.username){ try{ localStorage.setItem('ryzzAccountLabel:' + sid, data.username); }catch(e){} } }
    else if(cached){ ryzzCurrentAccountData = cached; }
    prfRenderProfil();
    if(cb) cb();
  });
}

function prfRenderProfil(){
  var data = ryzzCurrentAccountData || {};
  var fallbackLabel = null;
  if(ryzzCurrentAccountId){
    try{ fallbackLabel = localStorage.getItem('ryzzAccountLabel:' + ryzzCurrentAccountId); }catch(e){ fallbackLabel = null; }
  }
  var username = data.username || fallbackLabel || (ryzzCurrentAccountId ? 'Akun Saya' : '-');
  var email = data.email || (fallbackLabel && fallbackLabel.indexOf('@') > -1 ? fallbackLabel : '') || '-';
  var elName = document.getElementById('prfName'); if(elName) elName.textContent = username;
  var elUser = document.getElementById('prfFieldUsername'); if(elUser) elUser.textContent = username;
  var elEmail = document.getElementById('prfFieldEmail'); if(elEmail) elEmail.textContent = email;
  prfUpdateModuleStatus();
  prfSetAvatar(data.avatar || null);
  if(prfToggleAutoLock) prfToggleAutoLock.checked = typeof data.autoLockEnabled === 'boolean' ? data.autoLockEnabled : true;
  if(prfToggleSecureLogin) prfToggleSecureLogin.checked = typeof data.secureLoginEnabled === 'boolean' ? data.secureLoginEnabled : true;
  if(prfToggleActivityLog) prfToggleActivityLog.checked = data.activityLogEnabled === true;
  updatePasscodeToggleUI();
}

function prfOpenModal(id){ var el = document.getElementById(id); if(el) el.classList.add('open'); }
function prfCloseModal(id){ var el = document.getElementById(id); if(el) el.classList.remove('open'); }


function prfSaveSandi(){
  var oldVal = prfPwOld ? prfPwOld.value : '';
  var newVal = prfPwNew ? prfPwNew.value : '';
  var confirmVal = prfPwConfirm ? prfPwConfirm.value : '';
  if(prfSandiError) prfSandiError.style.display = 'none';
  if(!oldVal || !newVal || !confirmVal){
    if(prfSandiError){ prfSandiError.textContent = 'Lengkapi semua kolom kata sandi'; prfSandiError.style.display = 'block'; }
    return;
  }
  if(!ryzzCurrentAccountData || typeof ryzzCurrentAccountData.password === 'undefined'){
    if(prfSandiError){ prfSandiError.textContent = 'Data akun belum termuat. Periksa koneksi internet lalu buka lagi menu ini.'; prfSandiError.style.display = 'block'; }
    return;
  }
  if(oldVal !== ryzzCurrentAccountData.password){
    if(prfSandiError){ prfSandiError.textContent = 'Kata sandi saat ini salah'; prfSandiError.style.display = 'block'; }
    return;
  }
  if(newVal.length < 6){
    if(prfSandiError){ prfSandiError.textContent = 'Kata sandi baru minimal 6 karakter'; prfSandiError.style.display = 'block'; }
    return;
  }
  if(newVal !== confirmVal){
    if(prfSandiError){ prfSandiError.textContent = 'Konfirmasi kata sandi tidak cocok'; prfSandiError.style.display = 'block'; }
    return;
  }
  if(!fbDb || !ryzzCurrentAccountId){ hbToast('Tidak ada koneksi akun'); return; }
  prfSaveSandiBtn.disabled = true;
  fbDb.collection('ryzz_accounts').doc(ryzzCurrentAccountId).update({ password: newVal }).then(function(){
    ryzzCurrentAccountData = Object.assign({}, ryzzCurrentAccountData, { password: newVal });
    if(prfPwOld) prfPwOld.value = '';
    if(prfPwNew) prfPwNew.value = '';
    if(prfPwConfirm) prfPwConfirm.value = '';
    prfSaveSandiBtn.disabled = false;
    hbToast('Kata sandi berhasil diperbarui');
  }).catch(function(){
    prfSaveSandiBtn.disabled = false;
    hbToast('Gagal memperbarui kata sandi, periksa koneksi internet');
  });
}
if(prfSaveSandiBtn) prfSaveSandiBtn.addEventListener('click', prfSaveSandi);

if(prfToggleAutoLock) prfToggleAutoLock.addEventListener('change', function(){
  ryzzAutoLockEnabled = prfToggleAutoLock.checked;
  ryzzResetAutoLockTimer();
  prfSaveAccountFields({ autoLockEnabled: prfToggleAutoLock.checked }, prfToggleAutoLock.checked ? 'Kunci otomatis diaktifkan' : 'Kunci otomatis dinonaktifkan');
});
if(prfToggleSecureLogin) prfToggleSecureLogin.addEventListener('change', function(){
  prfSaveAccountFields({ secureLoginEnabled: prfToggleSecureLogin.checked }, prfToggleSecureLogin.checked ? 'Login aman diaktifkan' : 'Login aman dinonaktifkan');
});
if(prfToggleActivityLog) prfToggleActivityLog.addEventListener('change', function(){
  prfSaveAccountFields({ activityLogEnabled: prfToggleActivityLog.checked }, prfToggleActivityLog.checked ? 'Riwayat aktivitas diaktifkan' : 'Riwayat aktivitas dinonaktifkan');
});
safeOn('prfPolaManageBtn', 'click', openBuatPolaScreen);
safeOn('prfPolaDisableBtn', 'click', function(){
  if(hasPasscode()) openPasscode('disable');
});
safeOn('prfMenuPola', 'click', openBuatPolaScreen);

safeOn('prfAvatarBox', 'click', function(e){
  if(e.target.closest('#prfAvatarRemoveBtn')) return;
  var input = document.getElementById('prfAvatarInput');
  if(input) input.click();
});
safeOn('prfAvatarRemoveBtn', 'click', function(e){
  e.stopPropagation();
  if(!ryzzCurrentAccountId){ hbToast('Tidak ada koneksi akun'); return; }
  if(!confirm('Hapus foto profil dan kembalikan ke tampilan default?')) return;
  prfSetAvatar(null);
  prfSaveAccountFields({ avatar: '' }, 'Foto profil dihapus');
});
safeOn('prfAvatarInput', 'change', function(e){
  var f = e.target.files && e.target.files[0];
  e.target.value = '';
  if(!f) return;
  if(!ryzzCurrentAccountId){ hbToast('Tidak ada koneksi akun'); return; }
  if(!/^image\//.test(f.type)){ hbToast('Format file harus berupa gambar'); return; }
  if(f.size > 5 * 1024 * 1024){ hbToast('Ukuran foto maksimal 5MB'); return; }
  var reader = new FileReader();
  reader.onload = function(){
    var dataUrl = reader.result;
    if(typeof dataUrl === 'string' && dataUrl.length > 900000){
      hbToast('Foto terlalu besar setelah diproses, pilih foto lain');
      return;
    }
    prfSetAvatar(dataUrl);
    prfSaveAccountFields({ avatar: dataUrl }, 'Foto profil diperbarui');
  };
  reader.onerror = function(){ hbToast('Gagal membaca file foto'); };
  reader.readAsDataURL(f);
});

safeOn('prfMenuSandi', 'click', function(){ prfOpenModal('prfModalSandi'); });
safeOn('prfMenuBantuan', 'click', function(){ prfOpenModal('prfModalBantuan'); });
safeOn('prfMenuPrivasi', 'click', function(){
  prfOpenModal('prfModalPrivasi');
  prfRefreshFromSession();
  try{
    window.ryzzCollectDeviceInfo().then(function(info){
      var el = document.getElementById('prfDeviceInfoText');
      if(el) el.textContent = (info.brand !== 'Tidak diketahui' ? info.brand : info.platform) + ' - ' + info.browser;
    }).catch(function(){});
  }catch(e){}
});
safeOn('prfSandiCloseBtn', 'click', function(){ prfCloseModal('prfModalSandi'); });
safeOn('prfBantuanCloseBtn', 'click', function(){ prfCloseModal('prfModalBantuan'); });
safeOn('prfPrivasiCloseBtn', 'click', function(){ prfCloseModal('prfModalPrivasi'); });
safeOn('prfHapusSesiBtn', 'click', function(){ hbToast('Satu akun hanya aktif di satu perangkat, tidak ada sesi lain'); });
safeOn('prfLogoutBtn', 'click', function(){
  var el = document.getElementById('logoutConfirmBackdrop');
  if(el) el.classList.add('show');
});

try{
  document.querySelectorAll('.prf-faq-q').forEach(function(q){
    q.addEventListener('click', function(){
      var item = q.closest('.prf-faq-item');
      var wasOpen = item.classList.contains('open');
      document.querySelectorAll('.prf-faq-item').forEach(function(i){ i.classList.remove('open'); });
      if(!wasOpen) item.classList.add('open');
    });
  });
}catch(e){}

try{ prfRefreshFromSession(); }catch(e){}